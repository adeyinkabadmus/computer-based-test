<?php
    session_start();
    require_once("databaseconnection/connection.inc.php");
    class updateuserstate extends connection {
        private $username;
        private $qa;
        public $timeleft;
        function __construct($username, $timeleft, $qa) {
            parent::__construct();
            $this->timeleft = $timeleft;
            $this->qa = $qa;
            $this->username = $username;
            
            $this->updateusertimestamp();
        }

        function updateusertimestamp() {
            $query = $this->conn_cbt->prepare("UPDATE tbl_logforall SET trackuseractivestate = :currentstate WHERE matricno = :matricnumber");
            $currenttime = (string)time();
            $query->bindParam(":currentstate", $currenttime);
            $query->bindParam(":matricnumber", $this->username);
            if ($query->execute()) {
                $q = $this->conn_cbt->prepare("UPDATE tbl_timleft SET timeleft = :tl WHERE matricno = :matno AND coursecode = :cc");
                $q->bindParam(":tl", $this->timeleft);
                $q->bindParam(":matno", $this->username);
                $q->bindParam(":cc", $_SESSION['course']);
                $q->execute();
                $this->updateAnswers();
            } else {
                print("Update failed");
            }
        }

        function updateAnswers() {
            $quer = $this->conn_cbt->prepare("UPDATE tbl_temp SET ans = :ans WHERE question = :ques");
            foreach($this->qa as $key=>$value) {
                $quer->bindParam(":ans", $value);
                $quer->bindParam(":ques", $key);
                $quer->execute();
            }
            $this->checkState(); 
        }

        function checkState() {
            $q2 = $this->conn_cbt->prepare("SELECT blockstate FROM tbl_timleft WHERE matricno = :matno");
            $q2->bindParam(":matno", $this->username);
            $q2->execute();
            if ($q2->rowCount() > 0) {
                $f = $q2->fetch(PDO::FETCH_OBJ);
                if ($f->blockstate == 1) {
                    print("blocked");
                }
            }
        }

        function __destruct() { 
            $this->conn_cbt = null;
        }
    }
    $timeleft = $_POST['timeleft'];
    $qa = json_decode($_POST['ques']);
    //var_dump($qa);
    $obj = new updateuserstate($_SESSION['username'], $timeleft, $qa);
?>