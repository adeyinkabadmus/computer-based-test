<?php
    session_start();
    require_once("databaseconnection/connection.inc.php");
?>
<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="style/indexstyle.css" type="text/css" rel="stylesheet"/>
        <script src="javascript/login.js"></script>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
     
    </head>
    <body>
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-offset-4 col-lg-4 col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6">
                    <div class='alert alert-danger' style='border-bottom:3px solid #d9534f'><b><i class='fa fa-ban'></i> When time is up, your already selected answers will be automatically submitted<br />
                        You are not allowed to reload the page. Reloading the page might cause the server to log you out forcefully and may barr you from writing the exam as this is considered an act of malpractice</b>
                    </div>
                    <form class="form panel panel-primary" method="POST" action="#" name="loginForm" onsubmit="return(validateLogin())">
                        <div class="form-group panel-heading text-center">
                            <h4>Log in here</h4>
                        </div>
                        <div class='panel-body'>
                            <?php
                                require("login.php");    
                            ?>
                            
                            <div id="report"></div>
                            <div class="form-group">
                                <!--<label for="username" class="control-label">Matriculation Number</label>-->
                                <span><i class="fa fa-user" id="fa-user"></i> <input type="text" placeholder="Enter Matriculation number" name="username" id="userName"></span>
                            </div>
                        
                            <div class="form-group">
                                <button type="submit" style="width:100%" class="btn btn-primary" onclick="validateLogin()" name="login" id="loginBtn">Log in</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
       <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
      <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>