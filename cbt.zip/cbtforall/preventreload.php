<?php
    session_start();
    require_once("databaseconnection/connection.inc.php");
    class preventreload extends connection {
        function __construct() {
            parent::__construct();
            $this->redirectUser();
        }

        function prevReload() {
            $query = $this->conn_cbt->prepare("INSERT INTO tbl_blocked (matricno, stuname, faculty, department) VALUES (:matricnumber, :stuname, :faculty, :dept)");
            $query->bindParam(":matricnumber", $_SESSION['username']);
            $query->bindParam(":stuname", $_SESSION['stuname']);
            $query->bindParam(":faculty", $_SESSION['faculty']);
            $query->bindParam(":dept", $_SESSION['department']);

            if ( $query->execute()){
                return true;    
            } else {
                return false;    
            }
        }

        function redirectUser() {
            if ($this->prevReload()) {
                //print("here o");
                //header("Location:logout.php");
                //exit();
                print("<script>window.location = 'logout.php'</script>");
            } else {
                //print("not here o");
                print("<script>alert('An error occurred, please contact center administrator')</script>");
                exit();
            }
        }

        function __destruct() {

            $this->conn_cbt = null;
        }
    }
    $prevReload = new preventreload();
?>