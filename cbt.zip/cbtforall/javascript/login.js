function validateLogin() {
    let user = document.loginForm.username;
    //alert(user.value + " : " + pass.value)
    if (user.value == "" ){
        document.getElementById("userName").style.borderBottom = "2px solid red";
        document.getElementById("fa-user").style.color = "red"
        user.focus();
        return false;
    }

    if (document.getElementById("ui").checked == false && document.getElementById("nce").checked == false && document.getElementById("lasu").checked == false) {
        document.getElementById("schOpt").style.borderBottom = "2px solid red";
        document.getElementById("schOpt").focus();
        return false;
    }
}
