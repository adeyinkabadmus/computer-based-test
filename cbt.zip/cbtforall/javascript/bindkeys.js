document.getElementById("body").addEventListener('keydown', function(e) {
    let getKeyCode = e.keyCode;
    if (getKeyCode == 78) {
        //console.log("N was pressed " + getKeyCode);
        try {
            if (runapp.position < runapp.noOfQues) {
                runapp.renderQuestion(++runapp.quesIndex, ++runapp.position);
            } else {
                _el("next").style.display = "none";
            } 
        } catch (err) {
            console.log(runapp.position);
            _el("next").style.display = "none";
        }
    } else if (getKeyCode == 80) {
        //console.log("P was pressed " + getKeyCode);
        try {
            if (runapp.position > 1) {
                runapp.renderQuestion(--runapp.quesIndex, --runapp.position);
            } else {
                _el("prev").style.display = "none";
            }
        } catch (err2) {
            _el("prev").style.display = "none";
        } 
    } else if (getKeyCode == 83) {
        //console.log("S was pressed " + getKeyCode);
        runapp.submitAnswers();
    } else if (getKeyCode == 65) {
        //console.log("A was pressed " + getKeyCode);
        _el('aOpt').checked = true;
        runapp.saveAns(curQues.innerText, aOpt.value);
    } else if (getKeyCode == 66) {
        //console.log("B was pressed " + getKeyCode);
        _el('bOpt').checked = true;
        runapp.saveAns(curQues.innerText, bOpt.value);
    } else if (getKeyCode == 67) {
        //console.log("C was pressed " + getKeyCode);
        _el('cOpt').checked = true;
        runapp.saveAns(curQues.innerText, cOpt.value);
    } else if (getKeyCode == 68) {
        //console.log("D was pressed " + getKeyCode);
        _el('dOpt').checked = true;
        runapp.saveAns(curQues.innerText, dOpt.value);
    }
}, false);