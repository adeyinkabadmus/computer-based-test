<?php

    class connection {
        
        public $conn_cbt;
        private $servername;
        private $username;
        private $password;
        private $databasename;

        function __construct() {
            $this->servername = "localhost";
            $this->username = "root";
            $this->password = "root";
            $this->databasename = "cbt";
        
            $this->connectToDB();
        }
        function connectToDB() {
            try{

                $conn = new PDO("mysql:host=localhost;dbname=cbt", $this->username, $this->password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $this->conn_cbt = $conn;
                //print("Connection successful");

            } catch (PDOException $e) {
                throw new Exception("Database connection failed");
                //print ("Connection failed:" .$e->getMessage());
            }
        }
    }
?>
