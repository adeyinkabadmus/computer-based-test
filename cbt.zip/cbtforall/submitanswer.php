<?php
    session_start();
    require_once("databaseconnection/connection.inc.php");
    class submitanswer extends connection {
        public $matno;  //student's matric number
        public $ans;  //answers entered by the studnet
        private $schTable;
        private $logTable;
        private $stuscore; //holds student's score

        function __construct($matricNumber, $ans) {
            parent::__construct();
            $this->matno = $matricNumber;
            $this->ans = $ans;
            $this->stuscore = 0;
            
            $this->submitAnswers();
        }

        function submitAnswers() {
            $state = true;
            $numOfQuesAnswered = 0;
            foreach($this->ans as $key=>$value) {
                //print("$value");
                $numOfQuesAnswered++;
                $query = "UPDATE tbl_temp SET ans = :ans WHERE matricno = :matno AND coursecode = :cc AND question = :ques";
                $prepareQuery = $this->conn_cbt->prepare($query);
                $prepareQuery->bindParam(":matno", $this->matno);
                $prepareQuery->bindParam(":ques", $key);
                $prepareQuery->bindParam(":ans", $value);
                $prepareQuery->bindParam(":cc", $_SESSION['course']);
                if ($prepareQuery->execute()) {
                    $state *= true;
                    $this->computeresult($key, $value); //compute scores
                } else {
                    $state *= false;
                }
                if ($state == 0) {
                    print("<div class='alert alert-danger'>Submission could not be completed...., please retry submitting. If problem persists, please lodge complaints with a supervisor</div>");
                    break;
                }
                $prepareQuery = null;

            }
            if ($state == 1) {
                $savelogouttime = $this->conn_cbt->prepare("UPDATE tbl_logforall SET timeloggedout = :timeout WHERE matricno = :matricno");
                $time = gmdate("H:i:s", time() + 3600);
                $savelogouttime->bindParam(":timeout", $time);
                $savelogouttime->bindParam(":matricno", $this->matno);
                $savelogouttime->execute();
                $this->saveResult(); //save score in database
                print("<div class='container-fluid' style='padding-top:30px;'>
                    <div class='row'>
                        <div class='col-lg-6 col-md-6' align='right'>
                            <p><b>Matric Number</b></p>
                            <p><b>Name</b></p>
                            <p><b>Level</b></p>
                            <p><b>Department</b></p>
                            <p><b>Course</b></p>
                            <p><b>Answered</b></p>
                        </div>
                        <div class='col-lg-6 col-md-6' align='left'>
                            <p><b>".$_SESSION['username']."</b></p>
                            <p><b>".$_SESSION['stuname']."</b></p>
                            <p><b>".$_SESSION['level']."</b></p>
                            <p><b>".$_SESSION['department']."</b></p>
                            <p><b>".$_SESSION['course']."</b></p>
                            <p><b>$numOfQuesAnswered of ".$_SESSION['noOfQues']."</b></p>
                            <div class='alert alert-success' style='font-weight:bold;'>Submission successful</div>
                        </div>
                    </div>
                </div>");
                
            } else {
                print("<div class='container-fluid' style='padding-top:30px;'>
                <div class='row'>
                    <div class='col-lg-6 col-md-6' align='right'>
                        <p><b>Matric Number</b></p>
                        <p><b>Name</b></p>
                        <p><b>Level</b></p>
                        <p><b>Department</b></p>
                        <p><b>Course</b></p>
                        <p>Answered</p>
                    </div>
                    <div class='col-lg-6 col-md-6' align='left'>
                        <p><b>".$_SESSION['username']."</b></p>
                        <p><b>".$_SESSION['surname']." " .$_SESSION['othernames']."</b></p>
                        <p><b>".$_SESSION['level']."</b></p>
                        <p><b>".$_SESSION['department']."</b></p>
                        <p><b>".$_SESSION['course']."</b></p>
                        <div class='alert alert-danger' style='font-weight:bold;'>Submission failed</div>
                    </div>
                </div>
            </div>");
            }
            print("<div class='alert alert-info'><b>Please quietly leave the examination hall</b></div>");
        }
        function computeresult($question, $answer) {
            /*the submit answers function calls this function each time it loops through the answers submitted by the students
            *  and then compares each answer to the answer in the question database. increments the score if answers match. Does 
                nothing if answers don't match 
            */
            $computeresultquery = $this->conn_cbt->prepare("SELECT questions, answer FROM tbl_questions WHERE questions = :question AND stulevel = :stulevel AND departments = :dept AND coursecode = :coursecode ");
            $computeresultquery->bindParam(":question", $question);
            $computeresultquery->bindParam(":stulevel", $_SESSION['level']);
            $computeresultquery->bindParam(":dept", $_SESSION['department']);
            $computeresultquery->bindParam(":coursecode", $_SESSION['course']);
            $computeresultquery->execute();
            if ($fetchanswer = $computeresultquery->fetch(PDO::FETCH_ASSOC)) {
                if ($answer == $fetchanswer['answer']) {
                    $this->stuscore = $this->stuscore + 1; //increment score if answer equals answer in the questions database
                }
            }
        }
        function saveResult() {
            //save result in database
            $getpercentage = ($this->stuscore/$_SESSION['noOfQues']) * 100;
            $saveQuery = $this->conn_cbt->prepare("UPDATE tbl_log SET stuscore = :score, percentage = :percentage  WHERE matricno = :matricnumber AND coursecode = :coursecode");
            $saveQuery->bindParam(":score", $this->stuscore);
            $saveQuery->bindParam(":percentage", $getpercentage);
            $saveQuery->bindParam(":matricnumber", $this->matno);
            $saveQuery->bindParam(":coursecode", $_SESSION['course']);
            $saveQuery->execute(); //execute query   
        }
        function __destruct() {
            $this->conn_cbt = null;
        }
    }

    $matricNumber = $_POST['matricno'];
    $answer = json_decode($_POST['answers']);
    //var_dump($answer);
    //print (count($answer));
    $submit = new submitanswer($matricNumber, $answer);
?>