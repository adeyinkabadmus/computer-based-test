<?php

    session_start();
    require_once("databaseconnection/connection.inc.php");
    class getTime extends connection {
        function __construct() {
            parent::__construct();
            $this->timeToSpend();
        }

        public function timeToSpend() {
            //fetch the time taken for the exam from the database
            $prepsql = $this->conn_cbt->prepare("SELECT * FROM tbl_examtime WHERE department = :dept AND school = :sch AND course = :course");
            $prepsql->bindParam(":dept", $department);
            $prepsql->bindParam(":sch", $school);
            $prepsql->bindParam(":course", $course);
            $prepsql->execute();
            if ($prepsql->rowCount() > 0) {
                $fetch = $prepsql->fetch(PDO::FETCH_ASSOC);
                print($fetch['examtime']);
            } else {
                return false;
            }
        } 
        
        function __destruct() {
            $this->conn_cbt = null;
            $this->mysql = null;
            $this->uiNce = null;
        }
    }

    $gettime = new getTime();
?>