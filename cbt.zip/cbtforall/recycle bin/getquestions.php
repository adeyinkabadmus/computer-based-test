<?php
    session_start();
    require_once("databaseconnection/connection.inc.php");
    class getQuestions extends connection {
        private $getQues;
        function __construct() {
            parent::__construct();
            if ($_SESSION['school'] == "NCE") {
                $this->getQues = $this->conn_cbt->prepare("SELECT * FROM tbl_ncequestions WHERE stulevel = :level");    
            } else  if ($_SESSION['school'] == "LASU") {
                $this->getQues = null;
            } else if ($_SESSION['school'] == "UI") {
                $this->getQues = null;
            }
            $this->getques();
        }
        
        function getques() {
            $this->getQues->bindParam(":level", $_SESSION['level']);
            $this->getQues->execute();
            $numrows = $getQues->rowCount();
            if ($numrows > 0) {
                while ($fetch = $this->getQues->fetch(PDO::FETCH_ASSOC)) {
                    print($fetch['questions']);
                }
            }
        }

        function __destruct() {
            $this->mysql = null;
            $this->uiNce = null;
            $this->conn_cbt = null;
        }
    }
    $runGetQuestions = new getQuestions();
?>