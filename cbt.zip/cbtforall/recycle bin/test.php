<?php

    class test {
        public $mysql;
        private $servername = "localhost";
        private $username = "root";
        private $password = "root";
        private $databasename = "lasu";
        function __construct() {
            try{
                $conn = new PDO("mysql:host=$this->servername;dbname=$this->databasename", $this->username, $this->password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->mysql = $conn;
            } catch (PDOException $e) {
                $this->mysql = false;
            }
            
            
        }
        public function class1() {
            //print_r($this->mysql);
            if ($this->mysql) {
                return true;
            } else {
                return false;
            }
        }
    }

    class test2 extends test {
        function __construct() {
            parent::__construct();
            $this->class2();
        }
        
        function class2() {
            if (parent::class1()){
                print("Connection successful");
                $this->selectFromDB();
            } else {
                print("Connection not successful");
            }
        }

        function selectFromDB() {
            $sql = "SELECT * FROM students WHERE surname = :surname";
            $prepSql = $this->mysql->prepare($sql);
            if ($prepSql === false) {
                print("Statement is wrong");
            } else {
                print("Query is correct");
            }
        }
        function __destruct() {
            $this->mysql = null;
        }
    }

    $runObj = new test2();
    
?>