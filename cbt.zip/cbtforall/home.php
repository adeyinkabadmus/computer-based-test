-<?php
    /*start session from login page
    * Verify the authenticity of the session
    */
    session_start();
    $preventreload = $_SESSION['preventreload']++;
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
        exit();
    }
    if ($preventreload >= 1) { 
        header("Location:preventreload.php");
        exit();
    }
    //shuffle($_SESSION['quesAndAns']); //shuffle questions and answers to avoid students having questions in the same order
?>
<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="style/indexstyle.css" type="text/css" rel="stylesheet"/>
        <!--<script src="javascript/examapp.js"></script> -->
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
        <style>
            #myProgress {
                width:100%;
                background-color: grey;
            }
            #myBar {
                width: 1%;
                height: 10px;
                background-color: cornflowerblue;
            }
            body {
                padding-top:30px;
                overflow-x: none;
                font-size:12px;
            }
            .window-body #menu-nav {
                width:205px;
                height:100vh;
                background:#333;
                position:fixed;
                color:rgba(255, 255, 255, .5);
            }
            .window-body #main-nav {
                padding-top:30px; 
                padding-bottom:30px;
                padding-right:20px;
                padding-left:240px;
            }
            #timerBtn {
                font-size:15px;
                /*font-family:cursive;*/
                height:70px;
            }
            #key ul li {
                text-decoration:none;
                list-style:none;
            }
            .window-body #menu-nav #menu-nav-top {
                background-color: rgba(0,0,0,.7);
                height:20%;
                padding-top:37px;
            }
            #submitAll button{
                margin-top:99%;
                width:100%;
                height:45px;
            }
            #cover {
                position:fixed;
                height:100%;
                width:100%;
                background:rgba(0, 0,0, .3);
                top:0;
                left:0;
                display:none;
            }
            #cover #inner-cover {
                position:fixed;
                left:15%;
                height:60%;
                width:70%;
                top:10%;
                margin-top:5%;
                background:white;
                border-radius:10px;  
            }
        </style>
        <script type='text/javascript'>
            function _el(id) {
                return document.getElementById(id);
            }

            function cbtapp() {
                try {
                    this.xmlhttp = new XMLHttpRequest();
                } catch (err) {
                    try {
                        this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    } catch (err2) {
                        throw("A problem occured. Please reload the page to continue");
                    }
                }
                this.faculty = <?php print(json_encode($_SESSION['faculty'])); ?> ;
                this.matno = <?php print(json_encode($_SESSION['username'])) ?> ;
                this.noOfQues = <?php print(json_encode($_SESSION['noOfQues'])); ?>; //holds the number of questions
                this.stulevel = <?php print(json_encode($_SESSION['level'])) ?> ;//student's level
                this.keepalive = <?php print(json_encode($_SESSION['state'])); ?>; //clent uses this class member to know if there's been a previous login with this session
                this.ques = <?php print(json_encode($_SESSION['quesAndAns'])); ?>; //holds all questions   
                this.quesIndex = 0; //holds the index of each question the question array
                this.position = 1; //Holds the question number being answered
                this.answeredQues = {}; //list of answered questions

            }
            cbtapp.prototype.timing = function() {
                let q = this.answeredQues;
                let allTime = <?php print(json_encode($_SESSION['examtime'])) ?>;
                let thirtyPercentOfTime = allTime * 0.3; //Timer button should become red when thirty percent of allTime is reached
                let xmlhttp = this.xmlhttp;
                let timer = setInterval(function(){
                    let seconds = allTime % 60;
                    let minutes = Math.floor(allTime/60) % 60;
                    let hours = Math.floor(allTime/60/60) % 24;
                    _el("timer").innerHTML = hours + "h : " + minutes + "m : " + seconds + "s";
                    allTime--;
                    if (allTime <= thirtyPercentOfTime) {
                        _el("timerBtn").style.backgroundColor = "#d9534f";
                        _el("jumbo").style.border = "2px solid #d9534f"; //make border color of the frame that displays questions red
                        if (allTime <= 0) {
                            clearInterval(timer);
                            _el("timer").innerHTML = "Time is up"; //display when time is up
                            runapp.proceedToSubmit(); //submit answers chosen by candidate
                        }
                    }
                    if ((seconds % 11) == 0) {
                        //console.log(xmlhttp)
                        var response;
                        xmlhttp.open("POST", "updateuserstate.php");
                        xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                        xmlhttp.onreadystatechange = function() {
                            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                                response = xmlhttp.responseText;
                                if (response == "blocked") {
                                    window.location = 'logout.php';
                                }
                            }
                        }
                        //console.log(q);
                        xmlhttp.send("timeleft=" + allTime + "&ques=" + JSON.stringify(q));
                    }
                }, 1000);
            }
            cbtapp.prototype.renderQuestion = function(qIndex, pos) {
                
                //Render template for next question
                let currentQuestion = this.ques[qIndex]['question'];
                let opta = this.ques[qIndex]['option_a'];
                let optb = this.ques[qIndex]['option_b'];
                let optc = this.ques[qIndex]['option_c'];
                let optd = this.ques[qIndex]['option_d'];

                //curQues is the id of the question span while aOpt, bOpt, cOpt, dOpt are ids for the options
                _el("ques").innerHTML = "<b>Question "+ (pos) +":</b><span id='curQues'> " + currentQuestion + "</span>";
                _el("opt1").innerHTML = '<b>(A)</b> <input type="radio" name="questions" id="aOpt" value= "' + opta + '" onclick="runapp.saveAns(curQues.innerText, aOpt.value)">' + ' ' + opta; 
                _el("opt2").innerHTML = '<b>(B)</b> <input type="radio" name="questions" id="bOpt" value= "' + optb + '" onclick="runapp.saveAns(curQues.innerText, bOpt.value)">' + ' ' + optb;
                _el("opt3").innerHTML = '<b>(C)</b> <input type="radio" name="questions" id="cOpt" value= "' + optc + '" onclick="runapp.saveAns(curQues.innerText, cOpt.value)">' + ' ' + optc;
                _el("opt4").innerHTML = '<b>(D)</b> <input type="radio" name="questions" id="dOpt" value= "' + optd + '" onclick="runapp.saveAns(curQues.innerText, dOpt.value)">' + ' ' + optd;

                //display buttons based on the avaailable index of the question answered
                if (qIndex == 0) {
                    _el("prev").style.display = "none";
                } else {
                    if (qIndex == (this.noOfQues - 1)) {
                        _el('next').style.display = "none";
                        _el('prev').style.display = "block";
                    } else {
                        _el('next').style.display = "block";
                        _el("prev").style.display = "block";
                    }
                }

                this.keepAnswered(currentQuestion.trim(), this.answeredQues, qIndex); //function to keep the answers already chosen checked
                this.quesIndex = qIndex; //update the value of quesIndex to avoid picking the wrong questions when some previously checked question are gone back to or some yet unchecked are checked
                this.position = qIndex + 1; //update position to give the correct index of the question being answered
                
                //_el("here").innerHTML = "Position : " + pos; //_el("here").innerHTML += "<br />qIndex : " + qIndex; //_el("here").innerHTML += "<br />quesIndex : " + this.quesIndex;
            }
            cbtapp.prototype.saveAns = function(question, answer) {
                //console.log("Question : " + question + " Answer : " + answer);
                let ques = question.trim(); //trim whitespaces of question
                this.answeredQues[ques] = answer;
                //console.log(this.answeredQues);
                _el("answeredFromAll").innerHTML = "Answered " + Object.keys(this.answeredQues).length + " of " + this.noOfQues; //display the number of answered questions of all available questions
                console.log("this.quesindex : " + this.quesIndex);
                _el(this.quesIndex).style.backgroundColor = "#5cb85c"; //make button color green for questions that have been answered
               
            }
            cbtapp.prototype.keepAnswered = function(question, answeredQuestions, qIndex) {
                //console.log(answeredQuestions)
                //monitor previously answered questions to autocheck the ones already answered
                let checkQuesStatus = document.getElementsByName('questions'); //if an answer was picked or not
                let optionArray = ['option_a', 'option_b', 'option_c', 'option_d'];
                //ansQues = Object.keys(answeredQuestions);
                //console.log(ansQues);
                //console.log(question);
                if (question in answeredQuestions) {
                    for (let j in checkQuesStatus) {
                        for (let k in optionArray) {
                            if (answeredQuestions[question] == checkQuesStatus[j].value) {
                                //_el("qa").innerHTML = this.answeredQues[question]  + ' == ' + checkQuesStatus[j].value ;
                                checkQuesStatus[j].checked = true;
                                break;
                            }
                        }
                    }
                }
            }
            cbtapp.prototype.displayBtn = function() { 
                //create buttons to represent each question
                for (let i = 0; i < this.ques.length; i++) {
                    _el("allquestions").innerHTML += "<button class='btn btn-xs' id='"+ i +"' style='background:#d9534f' onclick='runapp.renderQuestion("+ i +", "+ (i+1) +")'>" + (i+1) +"</button>";
                }
                if (this.keepalive == 1) {
                    for (var i in this.ques) {
                        if (this.ques[i]['answer'] != null ) {
                            this.answeredQues[this.ques[i]['question']] = this.ques[i]['answer'];
                            document.getElementById(i).style.backgroundColor = "#5cb85c";
                            //console.log(this.answeredQues)
                        }
                        _el("answeredFromAll").innerHTML = "Answered " + Object.keys(this.answeredQues).length + " of " + this.noOfQues; //display the number of answered questions of all available questions
                    }
                }
            }  
            cbtapp.prototype.submitAnswers = function() {
                //submit questions and answers to server
                _el("cover").style.display = "block";
                let obj = _el("verifySubmitDiv");
                let defineTemplate = `<div class='contai'>
                                        <div class='row text-center'  style='padding:7%;'>
                                            <h3>Do you really want to submit now?</h3>
                                        </div>
                                        <div class='row' style='padding:0% 45%;'>
                                            <span>
                                                <button type='button' align='right' class='btn btn-success pull-right' id='confirmsubmit' onclick='runapp.proceedToSubmit()'>Yes</button>
                                            </span>
                                            <span>
                                                <button id='denysubmit' type='button' class='btn btn-danger pull-left' onclick='continueExam()'>No</button>
                                            </span>
                                        </div>
                                    </div>`;
                obj.innerHTML = defineTemplate;    
            }
            cbtapp.prototype.proceedToSubmit = function() {
                let xmlhttp = this.xmlhttp;
                _el("cover").style.display = "block";
                _el("verifySubmitDiv").style.display = 'none';
                let obj = _el("report");
                obj.style.display = "block";
                xmlhttp.open("POST", "submitanswer.php");
                xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        obj.innerHTML = xmlhttp.responseText;
                        setTimeout(function(){
                            window.location.href = "logout.php";
                        },5000);
                    }
                }
                xmlhttp.send("answers=" + JSON.stringify(this.answeredQues) + "&matricno=" + this.matno );
                //console.log(this.answeredQues);
                /*_el("cover").style.display = "block";
                let obj = _el("report");*/
            }
            function continueExam() {
                _el("cover").style.display = "none";
            }
            let runapp = new cbtapp();
        </script>      
    </head>
    <body onload="runapp.displayBtn(); runapp.timing(); runapp.renderQuestion(runapp.quesIndex, runapp.position)" id='body'>
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a> 
            </div>
            <div id='submitAl'>
                <button style='margin-right:40px' type='button' class='navbar-right btn btn-success btn-md navbar-btn' onclick="runapp.submitAnswers()">Submit</button>
            </div>
        </nav>
        <div class="window-body">
            <div id="menu-nav">
                <div id='menu-nav-top'>
                    <button id='timerBtn' class='btn btn-info text-center' type='button' style='width:100%;font-weight:bold;'><span id='timer'>0h : 0m : 0s</span><br />
                    <span id='answeredFromAll'>Answered 0 of <?php print($_SESSION['noOfQues']) ?></span></button>
                </div>
                <div id='menu-nav-bottom'>
                    <div id='key'>
                        <ul>
                            <li><button class='btn btn-success'></button> Answered questions</li>
                            <li><button class='btn btn-danger'></button> Unanswered questions</li>
                        </ul>
                    </div>
                    <div id='allquestions'></div>
                </div>
            </div>
            <div id="main-nav">
                <div class="row">
                    <span>
                        <button type="button" class="btn btn-primary pull-right"><i class='fa fa-user'></i> <?php print($_SESSION['stuname']); ?></button>
                        <button type='button' class='btn btn-primary pull-left'> <?php print($_SESSION['username'] . " | " . $_SESSION['level'] . "L | " .$_SESSION['course']) ?></button>
                    </span>
                </div>
                <div class='row'>
                    <?php
                        //var_dump($_SESSION['quesAndAns']);
                        //print("<div class='alert alert-success'>".$_SESSION['examtime']."</div>");
                    ?>
                    
                    <div style='padding-top:10px;' class="container-fluid">
                        <form class='form jumbotron' id="jumbo">
                            <div class="form-group" id="ques"></div>
                            <div class="form-group" id="opt1"></div>
                            <div class="form-group" id="opt2"></div>
                            <div class="form-group" id="opt3"></div>
                            <div class="form-group" id="opt4"></div>
                            <div class="form-group">
                                <span id='prev'><button class="btn btn-primary btn-sm pull-left" type="button" onclick="runapp.renderQuestion(--runapp.quesIndex, --runapp.position)">Previous</button></span>
                                <span id='next'><button type="button" class="btn btn-primary btn-sm pull-right" onclick="runapp.renderQuestion(++runapp.quesIndex, ++runapp.position)">Next</button></span>
                            </div>
                        </form>
                        <div id="here"></div>
                        <div id='qa'></div>
                    </div>
                </div>
                <!-- Displays exam details after submission --> 
                <div id='cover'>
                    <div id='inner-cover'>
                        <center><div id='verifySubmitDiv'></div></center>
                        <div id='report' style='padding-top:5%;'></div>
                    </div>
                </div>   
            </div>
            
        </div>
        <script src='javascript/bindkeys.js' type="text/javascript"></script>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
    <!-- button blue = 337ab7;
        button green = 5cb85c
        button red = d9534f -->
</html>