<?php

    class login extends connection {
        public $username;
        public $sch; //scnool expected to write exams
        public $dept;
        public $level;
        public $numofques ; //holds the number of questions to be answered by the student

        function __construct($user) {
            parent::__construct();
            $this->username = $user;

            $this->validateuser($this->username);
        }

        public function validateuser($user) {
        
            if (empty($user)) {
                print("<div class='alert alert-danger' style='width:100%; border-bottom:2px solid red'>You did not enter your matriculation number</div>");
            } else {
                //print("Username : " .$this->username ." Password : ".$this->password);
                $this->LoginVal();
            }
        }

        public function LoginVal() {
            
            $prepStatement = $this->conn_cbt->prepare("SELECT * FROM tbl_students WHERE matricno = :matricNumber");
            $prepStatement->bindParam(":matricNumber", $this->username);
	        
        	$prepStatement->execute();
        	if ($result = $prepStatement->fetch(PDO::FETCH_ASSOC)) {
		        $_SESSION['username'] = $result['matricno'];
		        $_SESSION['stuname'] = $result['studentname'];
		        $_SESSION['department'] = $result['department'];
		        $_SESSION['faculty'] = $result['faculty']; 
		        $_SESSION['level'] = $result['stulevel'];
		        $this->validateSchAndLevel();
		    } else {
		        print("<div class='alert alert-danger' style='width:100%; border-bottom:2px solid red;'>The matriculation number you entered is incorrect</div>");
	        }
            $prepStatement = null;
        }

        public function validateSchAndLevel() {
            //get student level but first comfirm if faculty and student's level has been granted access to write the exam
            $query = $this->conn_cbt->prepare("SELECT * FROM tbl_towriteexams WHERE stulevel = :level AND departmentname = :dept AND authorize = :value");
            $value = 1;
            $query->bindParam("value", $value);
            $query->bindParam(":level", $_SESSION['level']);
            $query->bindParam(":dept", $_SESSION['department']);
            $query->execute();
                            
            if ($query->rowCount() > 0){
                $res = $query->fetch(PDO::FETCH_ASSOC);
                $_SESSION['course'] = $res['course']; //keeps student's course in session
                $_SESSION['examtime'] = $res['examtime'];
                $this->numofques = $res['numofquestionstobeanswered'];
                $this->checkStudentRecordInTest($_SESSION['faculty']);
            } else {
                print("<div class='alert alert-danger' style='border-bottom:2px solid tomato'>You have not been granted access to write this exam</div>");
            }
            $query = null;
            //end      
        }

        private function checkStudentRecordInTest($sch) {
            //validate if student has once written the test
            $sql = "SELECT matricno FROM tbl_log WHERE matricno = :matricnumber AND coursecode = :course";//check if he has written exam before now
            $prepSql = $this->conn_cbt->prepare($sql);
            $prepSql->bindParam(":matricnumber", $this->username);
            $prepSql->bindParam(":course", $_SESSION['course']);
            $prepSql->execute();
            if ($prepSql->fetch(PDO::FETCH_ASSOC)) {
                print("<div class='alert alert-danger' style='border-bottom:3px solid tomato'>You are not permitted to write ".$_SESSION['course']." more than once</div>");
            } else {
               $this->checkBlockTable();
            }
        }

        public function checkBlockTable() {
            $sql = $this->conn_cbt->prepare("SELECT matricno FROM tbl_blocked WHERE matricno = :matricno and faculty = :sch");
            $sql->bindParam(":matricno", $_SESSION['username']);
            $sql->bindParam(":sch", $_SESSION['faculty']);
            $sql->execute();
            if ($fetch = $sql->fetch(PDO::FETCH_ASSOC)) {
                print("<div class='alert alert-danger' style='border-bottom:3px solid tomato'><b> You have been blocked from writing the exam... Please contact center administrator</b></div>");
            } else {
                $this->getQuestions();//get course questions and time taken for the examination from this member function 
            }
        }

        public function getQuestions() {  
            //fetch questions
            $arrayOfQuestions = array(); //create an array of questions. shuffle the array so that questions are not displayed to user in the same manner
            $checkTempTable = $this->conn_cbt->prepare("SELECT tbl_temp.matricno, tbl_temp.coursecode, tbl_temp.question, tbl_temp.opta, tbl_temp.optb, 
                                                        tbl_temp.optc, tbl_temp.optd, tbl_temp.ans, tbl_timleft.timeleft FROM tbl_temp, tbl_timleft WHERE tbl_temp.matricno = :matricnumber 
                                                        AND tbl_temp.coursecode = :cc AND tbl_timleft.matricno = :matricnumber AND tbl_timleft.coursecode = :cc");
            $checkTempTable->bindParam(":matricnumber", $_SESSION['username']);
            $checkTempTable->bindParam(":cc", $_SESSION['course']);
            $checkTempTable->execute();
            if ($checkTempTable->rowCount() > 0) {
                while ($fet = $checkTempTable->fetch(PDO::FETCH_ASSOC)) {
                    $array = array(); //associative array to hold questions, options and answers
                    $array['question'] = $fet['question'];
                    $array['option_a'] = $fet['opta'];
                    $array['option_b'] = $fet['optb'];
                    $array['option_c'] = $fet['optc'];
                    $array['option_d'] = $fet['optd'];
                    $array['answer'] = $fet['ans'];
                    $_SESSION['examtime'] = $fet['timeleft'] ; //update examtime session with the time left for the completion of the user's exam'
                    $_SESSION['state'] = 1; //tells the client if user had to stop writing exam after an issue came up and is just coming back online
                    //bind $array to $arrayOfQuestions
                    $arrayOfQuestions[] = $array;
                    
                }
                $_SESSION['quesAndAns'] = $arrayOfQuestions; //save exam questions into sessions
                $_SESSION['noOfQues'] = count($arrayOfQuestions); //number of questions fetched from the database
                $_SESSION['preventreload'] = 0;
                $this->saveDetailsInResult();
            } else {

                $query = $this->conn_cbt->prepare("SELECT * FROM tbl_questions WHERE stulevel = :level AND departments = :dept AND coursecode = :course");
                $query->bindParam(":level", $_SESSION['level']);
                $query->bindParam(":dept", $_SESSION['department']);
                $query->bindParam(":course", $_SESSION['course']);
                $query->execute();
                if ($query->rowCount() > 0) {
                    while ($fetchQuestions = $query->fetch(PDO::FETCH_ASSOC)) {
                        $array = array(); //associative array to hold questions, options and answers
                        $array['question'] = $fetchQuestions['questions'];
                        $array['option_a'] = $fetchQuestions['option_a'];
                        $array['option_b'] = $fetchQuestions['option_b'];
                        $array['option_c'] = $fetchQuestions['option_c'];
                        $array['option_d'] = $fetchQuestions['option_d'];
                        $_SESSION['state'] = 0;
                        $this->saveQuesInTempTable($fetchQuestions['questions'],$fetchQuestions['option_a'],$fetchQuestions['option_b'],$fetchQuestions['option_c'],$fetchQuestions['option_d']);
                        //bind $array to $arrayOfQuestions
                        $arrayOfQuestions[] = $array;
                    }
                    shuffle($arrayOfQuestions);
                    $convnumofquestype = (int)$this->numofques; //cast the number of questions to be answered by student which was returned from the database
                    //print(gettype((int)$this->numofques));
                    $arrayOfQuestions = array_slice($arrayOfQuestions, 0, $convnumofquestype);
                    //var_dump($arrayOfQuestions); //select only the number of questions the set in the database for the student to write
                    //print(count($arrayOfQuestions)); 
                    $this->updatetimelefttable(); //keep time left in a database table
                    $_SESSION['quesAndAns'] = $arrayOfQuestions; //save exam questions into sessions
                    $_SESSION['noOfQues'] = count($arrayOfQuestions); //number of questions fetched from the database
                    $_SESSION['preventreload'] = 0;
                    $this->saveDetailsInResult();
                } else {
                    print("<div class='alert alert-danger' style='border-bottom:2px solid red'>There was a problem fetching your questions. Please lodge complaints</div>");
                }
            }
            
        }
        function saveDetailsInResult() {
            $logintime = gmdate("F jS, Y, H:i:s", time() + 3600) ;
            $logUser = $this->conn_cbt->prepare("INSERT INTO tbl_log (matricno, coursecode, department, stu_level, time_logged_in, numberofquestions) VALUES (:matno, :coursecode, :department, :stulevel, :logintime, :noofques )");
            $logUser->bindParam(":matno", $this->username);
            $logUser->bindParam(":coursecode", $_SESSION['course']);
            $logUser->bindParam(":department", $_SESSION['department']);
            $logUser->bindParam(":stulevel", $_SESSION['level']);
            $logUser->bindParam(":logintime", $logintime);
            $logUser->bindParam(":noofques", $_SESSION['noOfQues']);
            if ($logUser->execute()) {
                $this->keeplog();
            }
        }
        function updatetimelefttable() {
            //keeps time for exam in the tbl_timleft table
            $query = $this->conn_cbt->prepare("INSERT INTO tbl_timleft (matricno, coursecode, timeleft) VALUES (:matricno, :coursecode, :timeleft)");
            $query->bindParam(":matricno", $_SESSION['username']);
            $query->bindParam(":coursecode", $_SESSION['course']);
            $query->bindParam(":timeleft", $_SESSION['examtime']);
            $query->execute();
        }
        function saveQuesInTempTable($question, $opta, $optb, $optc, $optd) {
            //saves us selected questions and options in table for storing questions, options and answers temporaril
            $quer = $this->conn_cbt->prepare("INSERT INTO tbl_temp (matricno, coursecode, question, opta, optb, optc, optd) VALUES (:matricno, :coursecode, :question, :opta, :optb, :optc, :optd)");
            $quer->bindParam(":matricno", $_SESSION['username']);
            $quer->bindParam(":coursecode", $_SESSION['course']);
            $quer->bindParam(":question", $question);
            $quer->bindParam(":opta", $opta);
            $quer->bindParam(":optb", $optb);
            $quer->bindParam(":optc", $optc);
            $quer->bindParam(":optd", $optd);
            $quer->execute();
        }
        function keeplog() {
            //store student info in the general log table
            $time = time() + 3600;
            $timein = (string)$time;
            $logsql = $this->conn_cbt->prepare("INSERT INTO tbl_logforall (matricno, stuname, faculty, department, course, timeloggedin) VALUES (:matricnumber, :studentname, :faculty, :department, :course, :timein)");
            $logsql->bindparam(":matricnumber", $_SESSION['username']);
            $logsql->bindparam(":studentname", $_SESSION['stuname']);
            $logsql->bindparam(":faculty", $_SESSION['faculty']);
            $logsql->bindparam(":department", $_SESSION['department']);
            $logsql->bindparam(":course", $_SESSION['course']);
            $logsql->bindparam(":timein", $timein);
            if ($logsql->execute()) {
                //print("");
                print("<script>window.location = 'home.php'</script>");
            } else {
                print("<div class='alert alert-danger' style='border-bottom:2px solid red'>An error occured while trying to log you in. Please contact center administrator</div>");
            }
        }

        function __destruct() { 

            $this->conn_cbt = null;
        
        }
    }
                                
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $loginClass = new login($username);
    }
?>                
