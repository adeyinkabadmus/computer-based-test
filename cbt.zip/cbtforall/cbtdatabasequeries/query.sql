CREATE DATABASE cbt;
CREATE TABLE `cbt`.`tbl_students` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `studentname` VARCHAR(70) NOT NULL ,
    `matricno` VARCHAR(70) NOT NULL ,
    `stulevel` VARCHAR(10) NOT NULL ,
    `faculty` VARCHAR(40) NOT NULL,
    `department` VARCHAR(40) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_towriteexams` 
( 
    `id` INT(11) NOT NULL AUTO_INCREMENT ,
    `departmentname` VARCHAR(70) NOT NULL ,
    `stulevel` VARCHAR(10) NOT NULL ,
    `course` VARCHAR(20) NOT NULL ,
    `numofquestionstobeanswered` INT(5) NOT NULL,
    `examtime` INT(7) UNSIGNED NOT NULL , 
    `authorize` INT(1) NOT NULL ,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_questions` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `questions` VARCHAR(1000) NOT NULL , 
    `questionimage` BLOB NULL DEFAULT NULL, 
    `option_a` VARCHAR(150) NOT NULL , 
    `option_b` VARCHAR(150) NOT NULL , 
    `option_c` VARCHAR(150) NOT NULL , 
    `option_d` VARCHAR(150) NOT NULL , 
    `answer` VARCHAR(150) NOT NULL ,
    `stulevel` VARCHAR(5) NOT NULL,
    `departments` VARCHAR(70) NOT NULL,
    `coursecode` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_scores` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `matricno` VARCHAR(30) NOT NULL , 
    `surname` VARCHAR(40) NOT NULL , 
    `othernames` VARCHAR(70) NOT NULL , 
    `scores` INT(5) NOT NULL , 
    `department` VARCHAR(50) NOT NULL , 
    `level` VARCHAR(5) NOT NULL , 
    `dateAndTime` VARCHAR(80) NOT NULL , 
    PRIMARY KEY (`id`), 
    UNIQUE (`matricno`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_test` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `matricno` VARCHAR(50) NOT NULL , 
    `ques` VARCHAR(600) NOT NULL , 
    `answer` VARCHAR(600) NOT NULL , 
    `coursecode` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_log` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `matricno` VARCHAR(50) NOT NULL , 
    `coursecode` VARCHAR(20) NOT NULL , 
    `department` VARCHAR(30) NOT NULL , 
    `stu_level` VARCHAR(10) NOT NULL , 
    `time_logged_in` VARCHAR(50) NOT NULL , 
    `stuscore` VARCHAR(4) NULL DEFAULT NULL,
    `numberofquestions` INT(11) UNSIGNED NOT NULL,
    `percentage` INT(5) UNSIGNED NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_blocked` 
( 
    `id` INT(11) NOT NULL AUTO_INCREMENT , 
    `matricno` VARCHAR(30) NOT NULL , 
    `stuname` VARCHAR(30) NOT NULL , 
    `faculty` VARCHAR(10) NOT NULL , 
    `department` VARCHAR(30) NOT NULL , 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_logforall` 
( 
    `id` INT(11) NOT NULL AUTO_INCREMENT ,
    `matricno` VARCHAR(20) NOT NULL ,
    `stuname` VARCHAR(50) NOT NULL ,
    `faculty` VARCHAR(50) NOT NULL , 
    `department` VARCHAR(30) NOT NULL , 
    `course` VARCHAR(20) NOT NULL , 
    `timeloggedin` VARCHAR(30) NOT NULL , 
    `timeloggedout` VARCHAR(30) NULL , 
    `trackuseractivestate` VARCHAR(50) NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_departments` 
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `departmentname` VARCHAR(70) NOT NULL , 
    `facultyname` VARCHAR(70) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_temp` 
( 
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `matricno` VARCHAR(30) NOT NULL,
    `coursecode` VARCHAR(50) NOT NULL, 
    `question` VARCHAR(1000) NOT NULL, 
    `opta` VARCHAR(100) NOT NULL,
    `optb` VARCHAR(100) NOT NULL,
    `optc` VARCHAR(100) NOT NULL, 
    `optd` VARCHAR(100) NOT NULL,
    `ans` VARCHAR(100) NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cbt`.`tbl_timleft`
( 
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `matricno` VARCHAR(50) NOT NULL , 
    `coursecode` VARCHAR(20) NOT NULL , 
    `timeleft` INT(7) NOT NULL , 
    `blockstate` INT(1) UNSIGNED NULL DEFAULT '0'; 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB; 

CREATE TABLE `cbt`.`tbl_admin` 
( 
    `id` INT(5) UNSIGNED NOT NULL AUTO_INCREMENT , 
    `username` VARCHAR(50) NOT NULL , 
    `password` VARCHAR(64) NOT NULL , 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;