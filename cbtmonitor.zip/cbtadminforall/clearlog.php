<?php

	class clearlog extends adminConn {
        function __construct() {
	        parent::__construct();

		    $this->clearlogtable();
        }

        function clearlogtable() {
        	$prepQuery = $this->mysql->prepare("TRUNCATE TABLE tbl_logforall");
        	if ($prepQuery->execute()) {
        		$prepSql = $this->mysql->prepare("TRUNCATE TABLE tbl_blocked");
        		if ($prepSql->execute()) {
					$sql = $this->mysql->prepare("TRUNCATE TABLE tbl_timleft");
					if ($sql->execute()) {
						print("<div class='alert alert-info'>Log successfully cleared</div>");
					}
        		} else {
        			print("<div class='alert alert-warning'>Failed to clear log</div>");
        		}
        	}
        	
        }
		
        function __destruct() {
        	$this->mysql = null;
        }
	}
    if (isset($_GET['clearlog'])) {
        $clearlog = new clearlog();
    }
	
?>
