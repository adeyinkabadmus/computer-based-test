<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:60px; 
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
            </style>
            <script>
            </script>
    </head>
    <body>
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='text-center'><a href="home.php" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <li><button type="button" id="logoutBtn" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</button></li>
            </ul>
        </div>
        <div class='main-content'>
            <div class="container-fluid"> 
                
                <div class='row'>
                    <div class=''>
                        <form class='form' action='' method='POST' role='form'>
                            <?php
                                class getAuthorizedDepts extends adminConn {
                                    function __construct() {
                                        parent::__construct();
                                        $this->getDepts();
                                    }
                                    function getDepts() {
                                        $query = $this->mysql->prepare("SELECT * FROM tbl_towriteexams");
                                        $query->execute();
                                        if ($query->rowCount()) {
                                            print("<table class='table'>
                                                <thead><tr><th>SN</th><th>SELECT</th><th>DEPARTMENT NAME</th><th>LEVEL</th><th>COURSE</th></tr></thead>
                                                <tbody>");
                                                $sn = 1;
                                            while ($fetch = $query->fetch(PDO::FETCH_OBJ)) {
                                                print("<tr>
                                                        <td>$sn</td>
                                                        <td><input type='checkbox' name='departments[]' value='".$fetch->departmentname."_".$fetch->stulevel."' ></td>
                                                        <td>".$fetch->departmentname."</td>
                                                        <td>".$fetch->stulevel."</td>
                                                        <td>".$fetch->course."</td> 
                                                      </tr>");
                                                $sn++;
                                            }
                                            print("</tbody></table><div class='form-group'><button type='submit' class='btn btn-primary' name='deleteBtn'>Delete</button></div>");
                                        } else {
                                            print("<div class='alert alert-danger'>No department has been granted access to write exams</div>");
                                        }
                                    }
                                    function __destruct() {
                                        $this->mysql = null;
                                    }
                                }
                                $classObject = new getAuthorizedDepts();
                            ?>
                        </form>
                        <?php
                            class deleteDepts extends adminConn {
                                //deletes the departments that have been previously granted permussion to write exams
                                public $dept;
                                public $school;
                                public $stulevel;

                                function __construct($departments) {
                                    parent::__construct();
                                    foreach ($departments as $value) {
                                        $splitValue = explode("_", $value);
                                        $dept = $splitValue[0];
                                        $level = $splitValue[1];

                                        //print($dept . " " .$sch." ".$level."<br />");
                                        
                                        if (!$this->delDepts($dept, $level)) {
                                            //if not true, quit deleting departments, alert an error containing the departmentname and school name that was not deleted
                                            print("<script>alert('Deleting department: $dept from school: $sch for level: $level failed');</script>");
                                            break;
                                        }
                                    }

                                }
                                function delDepts($dept, $level) {
                                    $delQuery = $this->mysql->prepare("DELETE FROM tbl_towriteexams WHERE departmentname = :deptname AND stulevel = :stulevel");
                                    $delQuery->bindParam(":deptname", $dept);
                                    $delQuery->bindParam(":stulevel", $level);
                                    if ($delQuery->execute()) {
                                        return true;
                                    } else {
                                        return false;
                                    }
                                }
                                function __destruct() {
                                    $this->mysql = null;
                                }
                            }
                            if (isset($_POST['deleteBtn'])) {
                                
                                $departments = $_POST['departments'];

                                if (count($departments) > 0) {
                                    $deleteDeptsClass = new deleteDepts($_POST['departments']); //runs the class to delete departments
                                    
                                } else {
                                    print("<script>alert('You did not select any department</script>");
                                }
                            }
                            
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>