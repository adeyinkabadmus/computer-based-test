<?php

	/**
	*  Unblock already blocked students
	*/
	require_once("db/dbconn.php");
	class unblockstudent extends adminConn
	{
		public $matno;

		function __construct($matno)
		{
			parent::__construct();
			$this->matno = $matno;
			$this->unblock();
		}
		
		function unblock() {
			$confirmifblocked = $this->mysql->prepare("SELECT matricno FROM tbl_blocked WHERE matricno = :matricno");
			$confirmifblocked->bindParam(":matricno", $this->matno);
			$confirmifblocked->execute();
			if ($confirmifblocked->rowCount() > 0) {
				$query = $this->mysql->prepare("DELETE FROM tbl_blocked WHERE matricno = :matricNumber");
				$query->bindParam(":matricNumber", $this->matno);
				if ($query->execute()){
					$query2 = $this->mysql->prepare("DELETE FROM tbl_logforall WHERE matricno = :matno");
					$query2->bindParam(":matno", $this->matno);
					if ($query2->execute()) {
						$query3 = $this->mysql->prepare("DELETE FROM tbl_log WHERE matricno = :matricnumber ");
						$query3->bindParam(":matricnumber", $this->matno);
						if ($query3->execute()) {
							$value = 0;
							$query4 = $this->mysql->prepare("UPDATE tbl_timleft SET blockstate = :value WHERE matricno = :matno");
							$query4->bindParam(":value", $value);
							$query4->bindParam(":matno", $this->matno);
							$query4->execute();
							$query4 = null;
						}
						$query3 = null;
					}
					$query2 = null;

					print("<div class='alert alert-success'> Student unblocked</div>");
				}
				else {
					print("<div class='alert alert-danger'> Student could not be unblocked</div>");
				}
				$query = null;
				

			} else {
				print("<div class='alert alert-danger'> Matric number was not found.</div>");
			}
			$confirmifblocked = null;
		}

		function __destruct() {
			$this->mysql = null;
		}
	}
	$matricnumber = $_GET['matricnumber'];
	$unblockstudent = new unblockstudent($matricnumber);
?>