<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:60px; 
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
            </style>
            <script>
                function checkall() {
                    var checkbtns = document.getElementsByName("depts[]");
                    console.log(checkbtns);
                    for (var i in checkbtns) {
                        if (checkbtns[i].checked == true) {
                            checkbtns[i].checked = false;
                        } else {
                            checkbtns[i].checked = true;
                        }
                    }
                }
            </script>
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top ">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
            <div>
                <form class='navbar-form navbar-right' action='' method='POST' style='color:#fff'>
                    <div class='form-group'>
                        <input type='text' class='form-control' name='matricnumber' placeholder='Enter matriculation number'>
                    </div>
                    <div class='form-group'>
                        <button type='submit' class='btn btn-primary' name='search'><i class='fa fa-search'></i></button>
                    </div>
                </form>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='text-center'><a href="home.php" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <li class='active'><a href="">View results</a></li>
                <li><a href="" data-target="#selectSchExam" data-toggle="modal">Enter exam questions</a></li>
                <li><a href="" data-target="#ExportData" data-toggle="modal">Export results</a></li>
                <li><button type="button" id="logoutBtn" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</button></li>
            </ul>
        </div>
        <div class='main-content'>
            <div class="container-fluid"> 
                
                <div class="modal fade" id="selectSchExam">  <!-- start modal enter exam questions -->
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                            <form method="POST" class="form" action="" id="selschform" name='quesform' onsubmit='return(val())'>
                                
                                <div class="form-group">
                                    <lebel class='control-label' for='school'>Enter course code</label>
                                    <input type='text' class='form-control' name='coursecode' id='courseCode'>
                                </div>
                                <div class="form-group">
                                    <lebel class='control-label' for='levels'>Level</label>
                                    <select class='form-control' name='levels'>
                                        <option>100</option>
                                        <option>200</option>
                                        <option>300</option>
                                        <option>400</option>
                                        <option>500</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-danger btn-sm" name="saveQuesBtn">Submit</button>
                                </div>
                                
                            </form>
                            <?php
                                if (isset($_POST['saveQuesBtn'])) {
                                    $_SESSION['schquestions'] = $_POST['schools']; //save school (That it's exam questions are about to be updated) in the session variable
                                    $_SESSION['coursecode'] = strtoupper($_POST['coursecode']);
                                    $_SESSION['levels'] = $_POST['levels'];
                                    //print($_SESSION['schforexam']);
                                    print("<script>window.location.href = 'savequestions.php'</script>");
                                }
                            ?>
                        </div>
                            <div class="modal-footer">
                                <button class="btn btn-info" data-dismiss="modal">Close window</button>
                            </div>
                        </div>
                    </div>
                </div>  <!-- end modal -->
                <div class='modal fade' id='ExportData'> <!-- start modal for data export to spreadsheet -->
                    <div class='modal-dialog'>
                        <div class='modal-content'>
                            <div class='modal-header'>
                                <button type='button' class='close' data-dismiss='modal'>&times;</button>
                                <h4>Select school to export data to spreadsheet</h4>
                            </div>
                            <div class='modal-body'>
                                <form class='form-inline' method='POST' action='export.php'>
                                    <div class='form-group' style='margin-left:35px;'>
                                        <select class="form-control" name="depts">
                                            <?php
                                                class fetchDepts extends adminConn {
                                                    function __construct() {
                                                        parent::__construct();

                                                        $this->getDepts();
                                                    }
                                                    function getDepts() {
                                                        $query = $this->mysql->prepare("SELECT * FROM tbl_departments");
                                                        $query->execute();
                                                        if ($query->rowCount() > 0) {
                                                            print("Founf");
                                                            while ($f = $query->fetch(PDO::FETCH_OBJ)) {
                                                                print("<option>".$f->departmentname."</option>");
                                                            }
                                                        }
                                                    }
                                                    function __destruct() {
                                                        $this->mysql = null;
                                                    }
                                                }
                                                $run = new fetchDepts();
                                            ?>
                                        </select>
                                    </div>
                                    <div class='form-group' style='margin-left:35px;'>
                                        <button type='submit' class='btn btn-success' name='exportbtn'>Export</button>
                                    </div>
                                </form>
                            </div>
                            <div class='modal-footer'>
                                <button class='btn btn-danger' data-dismiss='modal'>Close window</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- End modal -->

                <div id='results'>
                    <input type='checkbox' value='all' name='all' id='id' onclick='checkall()' /> All <br />
                    <?php
                        
                        class  viewresults extends adminConn {
                            public $ScoresTable;
                            function __construct($parameter=null) {
                                parent::__construct();
                                //print(gettype($parameter));
                                if ($parameter != null) {
                                    if (gettype($parameter) == 'array') {
                                        foreach ($parameter as $value) {
                                            $this->displayResults($value);
                                        }
                                    } else {
                                        $this->displayIndependentResult($parameter);
                                    }
                                }
                                
                            }
                            function displayDepts() {
                                $query = $this->mysql->prepare("SELECT * FROM tbl_departments");
                                $query->execute();
                                if ($query->rowCount() > 0) {
                                    print("<form name='alldepts' action='' method='POST'>");
                                    print("<div class='row'>
                                            <div class='col-lg-4 col-md-4'>");
                                                while ($fetch = $query->fetch(PDO::FETCH_OBJ)) {
                                                    print("<input type='checkbox' name=depts[] value='".$fetch->departmentname."' > ".$fetch->departmentname."<br />");
                                                }
                                    print("</div>");
                                    print("<div class='col-lg-4 col-md-4'><select name='level' class='form-control'><option>100</option>
                                        <option>200</option><option>300</option><option>400</option><option>500</option></select></div>");
                                    print("<div class='col-lg-4 col-md-4'><button type='submit' name='submitbutton' class='btn btn-primary btn-md'> Submit </button></div>");
                                    print("</div></form>");
                                }
                            }

                            function displayResults($val) {
                                $query = $this->mysql->prepare("SELECT * FROM tbl_log WHERE department = :dept ");
                                $query->bindParam(":dept", $val);
                                $query->execute();
                                if ($query->rowCount() > 0) {
                                    $sn = 0;
                                    print("<table class='table table-condensed'><thead><tr>");
                                    print("<th>SN</th><th>MATRIC NUMBER</th><th>COURSE CODE</th><th>DEPARTMENT</th><th>LEVEL</th><th>NUMBER OF QUESTIONS</th><th>SCORES</th><th>PERCENTAGE</th>");
                                    print("</tr></thead><tbody>");
                                    while($fetch = $query->fetch(PDO::FETCH_OBJ)) {
                                        $sn++;
                                        print("<tr><td>".$sn."</td><td>".$fetch->matricno."</td><td>".$fetch->coursecode."</td><td>".$fetch->department."</td><td>".$fetch->stu_level."</td><td>".$fetch->numberofquestions."</td><td>".$fetch->stuscore."</td><td>".$fetch->percentage."%</td></tr>");
                                    }
                                    print("</tbody></table>");
                                }
                            }

                            function displayIndependentResult($matno) {
                                $query = $this->mysql->prepare("SELECT * FROM tbl_log WHERE matricno = :matricnumber");
                                $query->bindParam(":matricnumber", $matno);
                                $query->execute();
                                if ($query->rowCount() > 0) {
                                    $fetch = $query->fetch(PDO::FETCH_OBJ);
                                    print("<table class='table table-condensed'><thead><tr>");
                                    print("<th>MATRIC NUMBER</th><th>COURSE CODE</th><th>DEPARTMENT</th><th>LEVEL</th><th>NUMBER OF QUESTIONS</th><th>SCORES</th><th>PERCENTAGE</th>");
                                    print("</tr></thead><tbody>");
                                    print("</td><td>".$fetch->matricno."</td><td>".$fetch->coursecode."</td><td>".$fetch->department."</td><td>".$fetch->stu_level."</td><td>".$fetch->numberofquestions."</td><td>".$fetch->stuscore."</td><td>".$fetch->percentage."%</td></tr>");
                                    print("</tbody></table>");
                                }
                            }

                            function __destruct() {
                                $this->mysql = null;
                            }
                        }
                        
                        if (isset($_POST['search'])) {
                            $matricno = $_POST['matricnumber'];
                            $view = new viewresults($matricno);
                        } else if (isset($_POST['submitbutton'])) {
                            $view = new viewresults($_POST['depts']);
                        } else {
                            $view = new viewresults();
                            $view->displayDepts();
                        }
                        
                    ?>

                <div>
            </div>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>