<?php

	/**
	*  Block already blocked students
	*/
	require_once("db/dbconn.php");
	class blockstudent extends adminConn
	{
		public $matno;

		function __construct($matno)
		{
			parent::__construct();
			$this->matno = $matno;
			$this->block();
		}
		
		function block() {
            $state = 1;
			$confirmifblocked = $this->mysql->prepare("SELECT tbl_timleft.matricno, tbl_logforall.matricno, tbl_logforall.stuname, tbl_logforall.faculty, 
                                                        tbl_logforall.department FROM tbl_timleft, tbl_logforall WHERE 
                                                        tbl_timleft.matricno = :matricno AND tbl_logforall.matricno = :matricno");
			$confirmifblocked->bindParam(":matricno", $this->matno);
			$confirmifblocked->execute();
			if ($confirmifblocked->rowCount() > 0) {
                $fetch = $confirmifblocked->fetch(PDO::FETCH_OBJ);
				$query = $this->mysql->prepare("UPDATE tbl_timleft SET blockstate = :bs WHERE matricno = :matricno");
				$query->bindParam(":matricno", $this->matno);
                $query->bindParam(":bs", $state);
				if ($query->execute()){
					$query2 = $this->mysql->prepare("INSERT INTO tbl_blocked (matricno, stuname, faculty, department) VALUES (:matno, :stuname, :faculty, :dept)");
					$query2->bindParam(":matno", $this->matno);
                    $query2->bindParam(":stuname", $fetch->stuname);
                    $query2->bindParam(":faculty", $fetch->faculty);
                    $query2->bindParam(":dept", $fetch->department);
					if ($query2->execute()) {
                        print("<div class='alert alert-success'> Student blocked</div>");
                    }
					$query2 = null;
				}
				else {
					print("<div class='alert alert-danger'> Student could not be blocked</div>");
				}
				$query = null;
			} else {
				print("<div class='alert alert-danger'> Matric number was not found.</div>");
			}
			$confirmifblocked = null;
		}

		function __destruct() {
			$this->mysql = null;
		}
	}
	$matricnumber = $_GET['matricnumber'];
	$unblockstudent = new blockstudent($matricnumber);
?>