<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:55px;
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
            </style>
            <script>
                function pasteans(id) {
                    let ans = document.getElementById(id).value.trim();
                    document.getElementById('correctAns').innerText = ans;
                    answer = document.getElementById('correctAns').innerText;
                    //console.log(answer + " " + ans);
                    //console.log(answer == ans);
                }
                function validateQuestions() {
                    let ques = document.getElementById("ques");
                    let opta = document.getElementById("optionA");
                    let optb = document.getElementById("optionB");
                    let optc = document.getElementById("optionC");
                    let optd = document.getElementById("optionD");
                    let ans = document.getElementById("correctAns");
                    
                    let arr = [ques, opta, optb, optc, optd];
                    for (let i in arr) {
                        if (arr[i].value == "") {
                            arr[i].style.borderColor = "tomato";
                            arr[i].focus();
                            return false;
                        } else {
                            arr[i].style.borderColor = "transparent";
                        }
                    }
                    if (ans.innerText == "") {
                        ans.style.borderColor = "tomato";
                        ans.focus();
                        return false;
                    }
                    //testdisplayall(ques, opta, optb, optc, optd, ans);
                    let ajaxFunc = new AjaxFunction();
                    ajaxFunc.sendTestQuestions(ques.value, opta.value, optb.value, optc.value, optd.value, ans.innerText);
                }

                function AjaxFunction() {
                    this.XMLHttpRequestObject = false;
                    if (window.XMLHttpRequest) {
                        this.XMLHttpRequestObject = new XMLHttpRequest();
                    } else if (window.ActiveXObject) {
                        this.XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    this.departments = <?php if(isset($_SESSION['deptsselected'])){print(json_encode($_SESSION['deptsselected']));}else{print(json_encode(0));}; ?>;
                    this.level = <?php print(json_encode($_SESSION['levels'])); ?>;
                    this.course = <?php print(json_encode($_SESSION['coursecode'])); ?>;
                    
                    if (this.departments == 0) {
                        alert("You have not selected any department(s) yet");
                    } else {
                        this.sendTestQuestions();
                    }
                    //console.log("Departments : " + this.departments);
                    //console.log("Level : " + this.level);
                    //console.log("Course : " + this.course);
                    //console.log("School : " + this.school);
                }
                AjaxFunction.prototype.sendTestQuestions = function(question, a, b, c, d, answer) {
                    //upload questions to the server which may contain images
                    //let quesImage = document.getElementById("quesImage").files[0];
                    let departments = JSON.stringify(this.departments);
                    let stulevel = this.level;
                    let coursecode = this.course;
                    
                    /*let formdata = new FormData();
                    formdata.append("departments", departments);
                    formdata.append("question", question);
                    formdata.append("optiona", a);
                    formdata.append("optionb", b);
                    formdata.append("optionc", c);
                    formdata.append("optiond", d);
                    formdata.append("answer", answer);
                    formdata.append("stulevel", stulevel);
                    formdata.append("coursecode", coursecode);
                    //formdata.append("quesimage", quesImage);
                    console.log(formdata);*/
                    let ajaxReq = this.XMLHttpRequestObject;
                    let dataSource = "savequestodb.php";
                    if(ajaxReq) {
                        let obj = document.getElementById("report");
                        ajaxReq.open("POST", dataSource);
                        ajaxReq.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                        ajaxReq.onreadystatechange = function()
                        {
                            if (ajaxReq.readyState == 4 && ajaxReq.status == 200) {
                                let response = ajaxReq.responseText;
                                if (response == "<div class='alert alert-success'>Successfully saved</div>") {
                                    document.getElementById("ques").value = "";
                                    document.getElementById("optionA").value = "";
                                    document.getElementById("optionB").value = "";
                                    document.getElementById("optionC").value = "";
                                    document.getElementById("optionD").value = "";
                                    document.getElementById("correctAns").innerText = "";
                                    obj.innerHTML = response;
                                } else {
                                    console.log("No => " + response)
                                }
                                obj.innerHTML = response;
                            }
                        }
                        //ajaxReq.send(formdata);
                        ajaxReq.send("departments=" + JSON.stringify(this.departments) + "&question=" + question + 
                                    "&optiona=" + a + "&optionb=" + b +"&optionc=" + c +"&optiond=" + d +
                                    "&answer=" + answer + "&stulevel=" + this.level+ "&coursecode=" + this.course );
                    } else {
                        document.getElementById(divID).innerHTML = "No AJAX request";
                    }
                }
            </script>
    </head>
    <body > <!--onload="ajaxFunc.getData('monitorexam.php','logdetails' )"> -->
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='text-center'><a href="home.php" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <!--<li><a href="" data-target="#selExam" data-toggle="modal">School to take exams</a></li>-->
                <li class='active'><a>Enter exam questions</a></li>
                <li><button type="button" id="logoutBtn" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</button></li>
            </ul>
        </div>
        <div class='main-content'>
            <div class="container-fluid">
                <div class='row'>
                    <div class='col-lg-8 col-md-8'>
                        <form class='form jumbotron' name='questionsform' action='' enctype='multipart/form-data'>
                            <div class='form-group'>
                                <button class='btn btn-success btn-sm' type='button'>COURSE CODE : <?php print($_SESSION['coursecode']) ?> 
                                    | LEVEL : <?php print($_SESSION['levels']) ?></button><br />
                                <?php //($_SESSION['schquestions']) stands for the school, $_SESSION['coursecode']) stands for course code selected while $_SESSION['levels']) stands for level ?>
                            </div>
                            <div id='report'></div>
                            <div class='form-group'>
                                <label class='control-label'>Question</label>
                                <textarea name='questions' class='form-control' id='ques' placeholder='Enter questions here' required></textarea>
                            </div>
                            <!--<div class='form-group'>
                                <label class='control-label'>Upload image</label>
                                <input type='file' class='form-control' name='quesimage' id='quesImage'>
                            </div>-->
                            <div class='form-group'>
                                <label class='control-label'>Option A</label>
                                <textarea type='text' class='form-control' name='optiona' id='optionA' required></textarea>
                            </div>
                            <div class='form-group'>
                                <label class='control-label'>Option B</label>
                                <textarea type='text' class='form-control' name='optionb' id='optionB' required></textarea>
                            </div>
                            <div class='form-group'>
                                <label class='control-label'>Option C</label>
                                <textarea type='text' class='form-control' name='optionc' id='optionC' required></textarea>
                            </div>
                            <div class='form-group'>
                                <label class='control-label'>Option D</label>
                                <textarea type='text' class='form-control' name='optiond' id='optionD' required></textarea>
                            </div>
                            <div class='form-group'>
                                <div class=''><label class='control-label'>Select one of the buttons to pick the answer</label></div>
                                <div class='col-lg-3'>
                                    <input type='radio' name='answer' onclick="pasteans('optionA')"> Option A
                                </div>
                                <div class='col-lg-3'>
                                    <input type='radio' name='answer' onclick="pasteans('optionB')"> Option B
                                </div>
                                <div class='col-lg-3'>
                                    <input type='radio' name='answer' onclick="pasteans('optionC')"> Option C
                                </div>
                                <div class='col-lg-3'>
                                    <input type='radio' name='answer' onclick="pasteans('optionD')"> Option D
                                </div>
                            </div>
                            <div class='form-group'>
                                <label class='control-label'>Answer</label>
                                <div class='well' style='font-size:14px;background:#fff;' id='correctAns'></div>
                            </div>
                            <div class='form-group'>
                                <button class='btn btn-primary' type='button' onclick='validateQuestions()' style='width:100%;'>Submit</button>
                            </div>
                        </form>
                    </div>
                    <div class='col-lg-4 col-md-4' id='deptscolumn'>
                        <?php
                            class fetchAllDepts extends adminConn {
                                //fetches departments from each school from the database
                                public $faculty;
                                public $departments;
                                public $level;
                                public $course;
                                public $examtime; 
                                function __construct() {
                                    parent::__construct();
                                    
                                    $this->selectDepts();
                                }

                                function selectDepts() {
                                    //fetch UI dep
                                    $deptarray = [];
                                    $levels = [100, 200, 300, 400, 500];
                                    $query = $this->mysql->prepare("SELECT * FROM tbl_departments");
                                    $query->execute();
                                    if ($query->rowCount() > 0) {
                                        while ($fetch = $query->fetch(PDO::FETCH_ASSOC)) {
                                            $deptarray[] = $fetch['departmentname'];
                                        }
                                        $this->departments = $deptarray;
                                        $this->level = $levels;
                                    }
                                }
                                function __destruct() {
                                    $this->mysql = null;
                                }
                            }
                            
                            $runClass = new fetchAllDepts();
                            
                        ?>
                        <form action='' method='POST' name='myForm' class='form'>
                            <?php
                                $deptschosen = [];
                                if (isset($_POST['selschs'])) {
                                    foreach($_POST['depts'] as $eachdept) {
                                        $deptschosen[] = $eachdept;
                                        print($eachdept);
                                    }
                                    $_SESSION['deptsselected'] = $deptschosen;
                                    print("<script>window.location.href= 'savequestions.php'</script>");
                                }
                                //print_r($deptschosen);
                                @$deptsselected = count($_SESSION['deptsselected']);
                                print("<div class='alert alert-info'> You have selected ". $deptsselected . " departments</div>");
                            ?>
                                <div class='form-group'>
                                <h5>SELECT DEPARTMENTS</h5>
                                <input type='checkbox' onclick='checkall()' name='checkalldepts' > All <br />
                                <script>
                                    function checkall() {
                                        //use the all checkbox to check and uncheck all other check boxes
                                        let allboxes = document.getElementsByName("depts[]");
                                        //console.log(allboxes);
                                        for (let i in allboxes) {
                                            //console.log(allboxes[i].value);
                                            if (allboxes[i].checked == true) {
                                                allboxes[i].checked = false;
                                            } else {
                                                allboxes[i].checked = true;
                                            }
                                        }
                                    }
                                </script>
                                <?php
                                    foreach ($runClass->departments as $value) {
                                        print("<input type='checkbox' name='depts[]' value='".$value."'> $value<br />");
                                    }
                                ?>
                            </div>
                            <div class='form-group'>
                                <button type='submit' class='btn btn-primary' name='selschs' >Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
                
                
            </div>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>