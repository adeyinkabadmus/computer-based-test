<?php

    print $name = $_FILES['filectrl']['name'];
    print $tmp_name = $_FILES['filectrl']['tmp_name'];
    print $size = $_FILES['filectrl']['size'];
    print $err = $_FILES['filectrl']['error'];
    print $type = $_FILES['filectrl']['type'];

    print("<br /><br />");

    print($_POST['departments'] . "<br />");
    print($_POST['question']. "<br />");
    print($_POST["optiona"]. "<br />");
    print($_POST["optionb"]. "<br />");
    print($_POST["optionc"]. "<br />");
    print($_POST["optiond"]. "<br />");
    print($_POST["answer"]. "<br />");
    print($_POST["stulevel"]. "<br />");
    print($_POST["coursecode"]. "<br />");
    print($_POST["school"]. "<br />");
?>