<?php
    require_once("db/dbconn.php");
    class saveQuesToDb extends adminConn{
        private $successlog; //checks if all queries were successful
        private $failurelog;
        function __construct($arrayofdepts, $ques, $opta, $optb, $optc, $optd, $ans, $level, $course) {
            parent::__construct();
            $this->successlog = true;
            $this->failurelog = [];
            
            foreach($arrayofdepts as $dept) {
                $this->executeQuery($dept, $ques, $opta, $optb, $optc, $optd, $ans, $level, $course);
            }  
            $this->renderReport(); 
        }
        private function executeQuery($dept, $ques, $opta, $optb, $optc, $optd, $ans, $level, $course) {
            
            $query = $this->mysql->prepare("INSERT INTO tbl_questions (questions, option_a, option_b, option_c, option_d, answer, stulevel, departments, coursecode) VALUES (:ques, :aopt, :bopt, :copt, :dopt, :answer, :studentlevel, :deptment, :ccode)");
            $query->bindParam(":ques", $ques);
            $query->bindParam(":aopt", $opta);
            $query->bindParam(":bopt", $optb);
            $query->bindParam(":copt", $optc);
            $query->bindParam(":dopt", $optd);
            $query->bindParam(":answer", $ans);
            $query->bindParam(":studentlevel", $level);
            $query->bindParam(":deptment", $dept);
            $query->bindParam(":ccode", $course);
            if ($query->execute()) {
                $this->successlog *= true;
            } else {
                $this->failurelog = $dept;
            }
        }
        public function renderReport() {
            if (count($this->failurelog) > 0) {
                if ($this->successlog == 1) {
                    print("<div class='alert alert-success'>Successfully saved but the questions for ".count($this->failurelog)." did not save</div><div class='alert alert-danger'>");
                    foreach ($this->failurelog as $eachfailed) {
                        print($eachfailed. ", ");
                    }
                    print("</div>");
                }
            } else {
                print("<div class='alert alert-success'>Successfully saved</div>");
            }
        }
        function __destruct() {
            $this->mysql = null;
        }
    }
    $departments = $_POST['departments']; //store all the deparments that was selected to answer this particular question
    $arraylisedepts = json_decode($departments);
    //var_dump($arraylisedepts);
    $question = trim($_POST['question']);
    $optiona = trim($_POST['optiona']);
    $optionb = trim($_POST['optionb']);
    $optionc = trim($_POST['optionc']);
    $optiond = trim($_POST['optiond']);
    $answer = trim($_POST['answer']);
    $stulevel = trim($_POST['stulevel']);
    $coursecode = trim($_POST['coursecode']);
    /*
    print("<br /><br />");
    print($_FILES['quesimage']['name']."<br />");
    print($_FILES['quesimage']['tmp_name']."<br />");
    print($_FILES['quesimage']['type']."<br />");
    print($_FILES['quesimage']['error']."<br />");
    print($_FILES['quesimage']['size']."<br />");
    //print("<div class='alert alert-success'>Successfully saved</div>");*/
    $savetodb = new saveQuesToDb($arraylisedepts, $question, $optiona, $optionb, $optionc, $optiond, $answer, $stulevel, $coursecode);
?>