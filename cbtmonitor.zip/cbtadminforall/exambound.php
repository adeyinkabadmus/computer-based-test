<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>OSCOED</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:60px; 
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
            </style>
            <script>
            </script>
    </head>
    <body>
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='text-center'><a href="home.php" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <li class='active'><a href="" data-target="#selExam" data-toggle="modal">School to take exams</a></li>
                <li><a href="" data-target="#selectSchExam" data-toggle="modal">Enter exam questions</a></li>
                <li><button type="button" id="logoutBtn" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</button></li>
            </ul>
        </div>
        <div class='main-content'>
            <div class="container-fluid"> 
                
                <div class="modal fade" id="selectSchExam">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                            <form method="POST" class="form" action="" id="selschform" name='quesform' onsubmit='return(val())'>
                                <div class="form-group">
                                    <lebel class='control-label' for='school'>Enter course code</label>
                                    <input type='text' class='form-control' name='coursecode' id='courseCode'>
                                </div>
                                <div class="form-group">
                                    <lebel class='control-label' for='levels'>Level</label>
                                    <select class='form-control' name='levels'>
                                        <option>100</option>
                                        <option>200</option>
                                        <option>300</option>
                                        <option>400</option>
                                        <option>500</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-sm" name="saveQuesBtn">Submit</button>
                                </div>
                                
                            </form>
                            <?php
                                if (isset($_POST['saveQuesBtn'])) {
                                    $_SESSION['schquestions'] = $_POST['schools']; //save school (That it's exam questions are about to be updated) in the session variable
                                    $_SESSION['coursecode'] = strtoupper($_POST['coursecode']);
                                    $_SESSION['levels'] = $_POST['levels'];
                                    //print($_SESSION['schforexam']);
                                    print("<script>window.location.href = 'savequestions.php'</script>");
                                }
                            ?>
                        </div>
                            <div class="modal-footer">
                                <button class="btn btn-info" data-dismiss="modal">Close window</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <?php
                    class fetchAllDepts extends adminConn {
                        //fetches departments from each school from the database
                        public $faculty;
                        public $departments;
                        public $level;
                        public $course;
                        public $examtime; 
                        function __construct() {
                            parent::__construct();
                            
                            $this->selectDepts();
                        }

                        function selectDepts() {
                            //fetch UI dep
                            $deptarray = [];
                            $levels = [100, 200, 300, 400, 500];
                            $query = $this->mysql->prepare("SELECT * FROM tbl_departments");
                            $query->execute();
                            if ($query->rowCount() > 0) {
                                while ($fetch = $query->fetch(PDO::FETCH_ASSOC)) {
                                    $deptarray[] = $fetch['departmentname'];
                                }
                                $this->departments = $deptarray;
                                $this->level = $levels;
                            }
                        }
                        function __destruct() {
                            $this->mysql = null;
                        }
                    }
                    
                    $runClass = new fetchAllDepts();
                ?>
                <form action='' method='POST' name='myForm' class='form'>
                    <div class='row'>
                        <div class='col-lg-4'>
                            <div class='form-group'>
                                <h5>DEPARTMENTS</h5>
                                <input type='checkbox' onclick='checkall()' name='checkalldepts' > All <br />
                                <script>
                                    function checkall() {
                                        let allboxes = document.getElementsByName("depts[]");
                                        //console.log(allboxes);
                                        for (let i in allboxes) {
                                            //console.log(allboxes[i].value);
                                            if (allboxes[i].checked == true) {
                                                allboxes[i].checked = false;
                                            } else {
                                                allboxes[i].checked = true;
                                            }
                                        }
                                    }
                                </script>
                                <?php
                                    foreach ($runClass->departments as $value) {
                                        print("<input type='checkbox' name='depts[]' value='".$value."'> $value <br />");
                                    }
                                ?>
                            </div>
                        </div>
                        <div class='col-lg-3'>
                            <div class='form-group'>
                                <h5>LEVELS</h5>
                                <select name='level' class='form-control'>
                                    <?php
                                        foreach ($runClass->level as $value) {
                                            print("<option>$value</option>");
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class='form-group'>
                                <h5>COURSE</h5>
                                <input type='text' class='form-control' placeholder='Enter course code' name='course' id='stucourse' required>
                            </div>
                            <div class='form-group'>
                                <h5>NUMBER OF QUESTIONS TO BE ANSWERED</h5>
                                <input type='number' class='form-control' placeholder='Enter number of questions to be answered' name='quesnum' id='quesNum' required>
                            </div>
                        </div>
                        <div class='col-lg-2'>
                            <h5>TIME</h5>
                            <div class='form-group'>
                                <input type='number' class='form-control' name='examtime' placeholder='Enter time in minutes' required>
                            </div>
                            <div class='form-group'>
                                <button type='submit' class='btn btn-primary btn-sm' name='saveBtn'>Submit</button>
                            </div>
                        </div>
                        <div class='col-lg-3'>
                            <div class='form-group'>
                                <h5>REPORT</h5>
                                <?php
                                    if (isset($_POST['saveBtn'])) {
                                        if (count($_POST['depts']) == 0 && empty($_POST['examtime']) && empty($_POST['course']) && empty($_POST['level']) && empty($_POST['quesnum'])) {
                                            print("<div class='alert alert-danger'>You did not fill required information</div>");
                                        }else{
                                            $time = $_POST['examtime'] * 60;
                                            $coursecode = strtoupper($_POST['course']);
                                            $level = $_POST['level'];
                                            $numofques = $_POST['quesnum'];
                                            $authorize = 1;
                                            class saveDepts extends adminConn {
                                                //save departments to database
                                                public $departments;
                                                public $level;
                                                public $course;
                                                public $examtime;
                                                public $auth;
                                                public $state;
                                                public $failed;
                                                public $success;
                                                public $numofques;
                                                function __construct($departments, $level, $coursecode, $time, $authorize, $numofques) {
                                                    parent::__construct();
                                                    $this->departments = $departments;
                                                    $this->level = $level;
                                                    $this->course = $coursecode;
                                                    $this->examtime = $time;
                                                    $this->auth = $authorize;
                                                    $this->failed = [];
                                                    $this->success = [];
                                                    $this->numofques = $numofques;
                                                    
                                                    $this->insertDepts();
                                                }
                                                public function insertDepts() {
                                                    foreach($this->departments as $value) {
                                                        $insertQuery = $this->mysql->prepare("INSERT INTO tbl_towriteexams (departmentname, stulevel, course, examtime, authorize, numofquestionstobeanswered) VALUES (:deptname, :stulevel, :course, :examtime, :auth, :numofques)");
                                                        $insertQuery->bindParam(":deptname", $value);
                                                        $insertQuery->bindParam(":stulevel", $this->level);
                                                        $insertQuery->bindParam(":course", $this->course);
                                                        $insertQuery->bindParam(":examtime", $this->examtime);
                                                        $insertQuery->bindParam(":auth", $this->auth);
                                                        $insertQuery->bindParam(":numofques", $this->numofques);
                                                        if ($insertQuery->execute()) {
                                                            $this->success[] = $value;
                                                        } else {
                                                            $this->failed[] = $value;
                                                        }
                                                    }
                                                }
                                                function __destruct() {
                                                    $this->mysql = null;
                                                }
                                            }
                                            //print_r($_POST['depts']);
                                            
                                            $saveDeptsrun = new saveDepts($_POST['depts'], $level, $coursecode, $time, $authorize, $numofques);
                            
                                            //verify if query execution was successful
                                            print("<div class='alert alert-info'>".count($_POST['depts'])." department(s) is/were selected</div>");
                                            print("<div class='alert alert-success'>".count($saveDeptsrun->success)." departments were saved</div>");
                                            print("<div class='alert alert-danger'>".count($saveDeptsrun->failed)." departments failed to save</div>");
                                        }
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>