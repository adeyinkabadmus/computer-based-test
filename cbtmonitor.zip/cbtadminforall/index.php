<?php
    
    session_start();
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta charset="utf-8">
    <title>OSCOED</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
    <link href="style/indexstyle.css" type="text/css" rel="stylesheet"/>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <style type="text/css">
            body {
                padding-top:10%;
            }
        </style>
</head>
<body>
    <nav class="navbar navbar-fixed-top navbar-inverse">
        <div class="navbar-header">
            <a class="navbar-brand">CBT</a>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-offset-3 col-lg-6">
                <form class="form panel panel-info" method="POST" action="" name="loginForm">
                    <div class="form-group panel-heading text-center">
                        <h3>Admin Login</h3>
                    </div>
                    <div class='panel-body'>
                        <div class="form-group">
                            <label for="username" class="control-label">Username</label>
                            <input type="text" class="form-control" placeholder="Enter username" name="username" id="userName">
                        </div>
                        <div class="form-group">
                            <label for="password" class="control-label">Password</label>
                            <input type="password" class="form-control" placeholder="Enter Password" name="password" id="passWord">
                        </div>
                        <div class="form-group">
                            <button type="submit" style="width:100%" class="btn btn-primary" name="login" id="loginBtn">Log in</button>
                        </div>

                        <?php
                            if (isset($_POST['login'])) {
                                if ($_POST['username'] == "cbtadmin" && $_POST['password'] == "admin123456admin") {
                                    $_SESSION['username'] = "Admin";
                                    //$_SESSION['startpoint'] = 0;
                                    print("<script>window.location = 'home.php' </script>");
                                } else {
                                    print("Username or password incorrect");
                                }
                            }

                        ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.1.js"></script>
  <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

</body>
</html>