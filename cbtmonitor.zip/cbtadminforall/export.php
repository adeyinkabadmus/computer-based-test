<?php
    require_once("db/dbconn.php");
    class  exportToExcel extends adminConn {
        public $dept;
        public $output;
        public $sch;
        function __construct($dept) {
            parent::__construct();
            $this->output = "";
            $this->dept = $dept;
            $this->displayResults();
        }
        
        function displayResults() {
            $query = $this->mysql->prepare("SELECT * FROM tbl_log WHERE department = :dept");
            $query->bindParam(":dept", $this->dept);
            $query->execute();
            $output = "";
            if ($query->rowCount() > 0) {
                $sn = 0;
                $output .= "<table class='table table-condensed'><thead><tr>";
                $output .= "<th>SN</th><th>MATRIC NUMBER</th><th>COURSE CODE</th><th>DEPARTMENT</th><th>LEVEL</th><th>NUMBER OF QUESTIONS</th><th>SCORES</th><th>PERCENTAGE</th>";
                $output .= "</tr></thead><tbody>";
                while($fetch = $query->fetch(PDO::FETCH_OBJ)) {
                    $sn++;
                    $output .= "<tr><td>".$sn."</td><td>".$fetch->matricno."</td><td>".$fetch->coursecode."</td><td>".$fetch->department."</td><td>".$fetch->stu_level."</td><td>".$fetch->numberofquestions."</td><td>".$fetch->stuscore."</td><td>".$fetch->percentage."</td></tr>";
                }
                $output .= "</tbody></table>";
            }
            $this->output = $output;
        }

        function __destruct() {
            $this->mysql = null;
            $filename = $this->dept."_".gmdate("F_jS_Y", time()+3600);
            header("Content-Type: application/xlsx");
            header("Content-Disposition:attachment; filename=$filename.xls");
            print($this->output);
        }
    }
    
    if (isset($_POST['exportbtn'])) {
        $dept = $_POST['depts'];
        $view = new exportToExcel($dept);
    }  
?>
