<?php
    //returns active and blocked students
    require_once("db/dbconn.php");
    class monitorexam extends adminConn{
        
        function __construct() {
            parent::__construct();
            $this->checkforupdate();
        }
        
        function checkforupdate() {
            $arr = [];
            //$sn = 1;
            //checking for the number of logged in students
            $fetchactive = $this->mysql->prepare("SELECT * FROM tbl_logforall");
            $fetchactive->execute();
            $fetchactiverownum = $fetchactive->rowCount();
            $arr['active'] = $fetchactiverownum;

            $num = 0;
            if ($fetchactiverownum > 0) {
                while($fetch = $fetchactive->fetch(PDO::FETCH_ASSOC)) {
                    if (((time() - (int)$fetch['trackuseractivestate']) > 15) && strlen($fetch['timeloggedout']) == 0) {
                        $num = $num + 1;
                    }
                }
            }
            $arr['inactive'] = $num; //get the number of inactive users

            //checking for the number of loggedout students
            $param = "";
            $fetchloggedout = $this->mysql->prepare("SELECT * FROM tbl_logforall WHERE timeloggedout != :parameter ");
            $fetchloggedout->bindParam(":parameter", $param );
            $fetchloggedout->execute();
            $fetchloggedoutrownum = $fetchloggedout->rowCount();
            $arr['loggedout'] = $fetchloggedoutrownum;

            //checking for the number of blocked students 
            $fetchblocked = $this->mysql->prepare("SELECT * FROM tbl_blocked");
            $fetchblocked->execute();
            $fetchblockedrownum = $fetchblocked->rowCount();
            $arr['blocked'] = $fetchblockedrownum;

            print(json_encode($arr));
        }
        
        function __destruct() {
            $this->mysql = null;
        }
    
    }
    
    $monExam = new monitorexam();

    ?>