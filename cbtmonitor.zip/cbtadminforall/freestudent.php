<?php

	/**
	*  free student that mistakenly got logged out
	*/
	require_once("db/dbconn.php");
	class freestudent extends adminConn
	{
		public $matno;

		function __construct($matno)
		{
			parent::__construct();
			$this->matno = $matno;
			$this->unblock();
		}
		
		function unblock() {
			$query = $this->mysql->prepare("DELETE FROM tbl_logforall WHERE matricno = :matricno");
			$query->bindParam(":matricno", $this->matno);
			if ($query->execute()) {
                $query2 = $this->mysql->prepare("DELETE FROM tbl_log WHERE matricno = :matricno");
			    $query2->bindParam(":matricno", $this->matno);
                if ($query2->execute()) {
                    print("<div class='alert alert-success'>Student can now log in</div>");
                } else {
                    print("<div class='alert alert-danger'>Failed</div>");
                }
            }
			
		}

		function __destruct() {
			$this->mysql = null;
		}
	}
	$matricnumber = $_GET['matricnumber'];
	$unblockstudent = new freestudent($matricnumber);
?>