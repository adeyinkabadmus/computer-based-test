<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
        exit();
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:60px; 
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
                label {
                    font-size:14px;
                    font-weight:bold;
                }
            </style>
            <script>
                
            </script>
    </head>
    <body onload="ajaxFunc.getData('monitorexam.php','logdetails')"> 
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='text-center'><a href="home.php" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <li><button type="button" id="logoutBtn" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</button></li>
            </ul>
        </div>
        <div class='main-content'>
                <div id='logdetails'></div>
                <?php
                    class deletequestions extends adminConn {
                
                        function __construct($deptname) {
                            parent::__construct();
                            if ($deptname == "all") {
                                $this->truncateQuesTable();
                            } else {
                                $this->deleteSpecificQues($deptname);
                            }
                        }

                        function truncateQuesTable() {
                            //truncates all tables that holds questions for all schools
                            foreach ($this->tablearray as $value) {
                                $query = $this->mysql->prepare("TRUNCATE TABLE tbl_questions");
                                if ($query->execute()) {
                                    print ("<script>alert('Table successfully cleared')</script>");
                                    print("<script>window.location.href='home.php'</script>");
                                }
                            }
                        }

                        function deleteSpecificQues($dept) {
                            //truncates table passed as a
                            $query = "DELETE FROM tbl_questions WHERE departments = :dept";
                            $query->bindParam(":dept", $dept);
                            if ($query->execute()) {
                                print ("<script>alert('Table successfully cleared')</script>");
                                print("<script>window.location.href='home.php'</script>");
                            }
                        }

                        function __destruct() {
                            $this->mysql = null;
                        }
                    }
                    if (isset($_POST['deletedeptsbtn'])) {
                        $deptname = $_POST['depts'];
                        //print($schname);
                        $deleteques = new deletequestions($deptname);
                    }           
                    
                ?>

        </div> <!-- END MAIN CONTENT -->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    </body>
</html>