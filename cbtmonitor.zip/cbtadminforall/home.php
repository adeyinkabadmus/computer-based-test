<?php
    session_start();
    include ("db/dbconn.php");
    if ($_SESSION['username'] == "") {
        header("Location:index.php");
        exit();
    }
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="utf-8">
        <title>CBT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <!-- Bootstrap -->
        <script src="javascript/adminapp.js"></script>
        <link href="css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <link href="" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
            <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->
            <style type="text/css">
                *{
                    box-sizing: border-box;
                }
                body {  
                    margin: 0;
                    padding: 0;
                    font-family: "Trebuchet MS", Helvetica, sans-serif; 
                    font-size:12px; 
                }
                .side-nav{
                    height: 100vh;
                    position: fixed;
                    width:200px;
                    background-color: #333;
                    padding-top:60px; 
                    line-height: 20px;
                }
                .side-nav .active {
                    background-color: #337ab7;
                }
                .side-nav ul {
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                .side-nav ul li {
                    padding: 10px 10px;
                    border-bottom: 1px solid cornflowerblue;
                }
                .side-nav ul li:hover {
                    background-color: #337ab7;
                }
                .side-nav ul li a {
                    color: #fff;
                    text-decoration: none;
                }
                .side-nav ul li a:hover {
                    color: #fff;
                }
                .side-nav ul li a span i {
                    color: teal;
                }
                .navbar {
                    background-color: #333;
                }
  
                .main-content {
                    padding-top: 60px;
                    padding-right:10px;
                    padding-left: 5px;
                    font-size: 11px;
                    line-height: 30px;
                    margin-left: 220px;
                }
                #selschform .form-group {
                    padding: 0px 40px;
                }
                label {
                    font-size:14px;
                    font-weight:bold;
                }
            </style>
            <script>
                function _$(id) {
                    return document.getElementById(id);
                }

                function val() {
                    let sch = 0;
                }

                function validate() {
                    let school = document.getElementsByName("school");
                    let state = false;
                    for (let i in school) {
                        if (school[i].checked) {
                            state = true;
                        }
                    }
                    if (state == false) {
                        _$("schreport").innerHTML = "<div class='alert alert-danger'>You did not select any option</div>";
                        return false;
                    }
                }

                function AjaxFunction() {
                    this.XMLHttpRequestObject = false;
                    if (window.XMLHttpRequest) {
                        this.XMLHttpRequestObject = new XMLHttpRequest();
                    } else if (window.ActiveXObject) {
                        this.XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    this.blocked = 0;
                    this.online = 0;
                    this.loggedout = 0;
                    this.lastrowfetchedid = 0;
                    this.inactive = 0;
                }
                AjaxFunction.prototype.unblockstu = function(matricno) {
                    //unblocks student by deleting their details from the table that holds blocked students
                    let ajaxReq = this.XMLHttpRequestObject;
                    let divID = _$('blockedstudentreport');
                    if (ajaxReq) {
                        ajaxReq.open("GET", "unblockstudent.php?matricnumber=" + matricno);
                        ajaxReq.onreadystatechange = function() {
                            if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
                                let report = ajaxReq.responseText;
                                divID.innerHTML = report;
                            }
                        }
                        ajaxReq.send(null);
                    }
                }  
                AjaxFunction.prototype.blockstu = function(matricno) {
                    //unblocks student by deleting their details from the table that holds blocked students
                    let ajaxReq = this.XMLHttpRequestObject;
                    let divID = _$('blockstureport');
                    if (ajaxReq) {
                        ajaxReq.open("GET", "blockstudent.php?matricnumber=" + matricno);
                        ajaxReq.onreadystatechange = function() {
                            if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
                                let report = ajaxReq.responseText;
                                divID.innerHTML = report;
                            }
                        }
                        ajaxReq.send(null);
                    }
                }  
                AjaxFunction.prototype.free = function(matricno) {
                    //unblocks student by deleting their details from the table that holds blocked students
                    let ajaxReq = this.XMLHttpRequestObject;
                    let divID = _$('allowstubackin');
                    if (ajaxReq) {
                        ajaxReq.open("GET", "freestudent.php?matricnumber=" + matricno);
                        ajaxReq.onreadystatechange = function() {
                            if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
                                let report = ajaxReq.responseText;
                                divID.innerHTML = report;
                            }
                        }
                        ajaxReq.send(null);
                    }
                }  
                AjaxFunction.prototype.getData = function(dataSource, divID) {
                    let last = this.lastrowfetchedid;
                    let ajaxReq = this.XMLHttpRequestObject;
                    let online = this.online;
                    let blocked = this.blocked;
                    let loggedout = this.loggedout;
                    let activestate = this.inactive;
                    //alert("Blocked " + blocked + " Active " + online);
                    setInterval(function() {
                        if(ajaxReq) {
                            //let obj = document.getElementById(divID);
                            ajaxReq.open("GET", dataSource);
                            console.log("Comparing parameters ");
                            ajaxReq.onreadystatechange = function()
                            {
                                if (ajaxReq.readyState == 4 && ajaxReq.status == 200) {
                                    let responseholder = ajaxReq.responseText;
                                    //console.log(responseholder);
                                    let parseresponse = JSON.parse(responseholder); //fetches an associative array of blocked and active users from database
                                    console.log(parseresponse);
                                    if (parseresponse.active != online) {
                                        //console.log("Parseresponse.active " + parseresponse.active);
                                        //console.log("this.online " + online);
                                        console.log("Changes found in the number of logged in students");
                                        //alert("Changes found in the number of logged in students");
                                        window.location.reload();
                                    }
        
                                    if (parseresponse.blocked != blocked) {
                                        //console.log("Parseresponse.blocked " + parseresponse.blocked);
                                        //console.log("this.blocked " + blocked);
                                        console.log("Changes found in the number of blocked students");
                                        //alert("Changes found in the number of blocked students");
                                        window.location.reload();
                                    }
                                    
                                    if (parseresponse.inactive != activestate) {
                                        //console.log("Parseresponse.inactive " + parseresponse.inactive);
                                        //console.log("this.inactive " + activestate);
                                        console.log("Changes found in the number of inactive students");
                                        //alert("Changes found in the number of inactive students");
                                        window.location.reload();
                                    } /*else {
                                        console.log("Parseresponse.inactive " + parseresponse.inactive);
                                        console.log("this.inactive " + activestate);
                                    }*/

                                    if (parseresponse.loggedout != loggedout) {
                                        //console.log("Parseresponse.loggedout " + parseresponse.loggedout);
                                        //console.log("this.loggedout " + loggedout);
                                        //alert("Changes found in the number of logged out students ");
                                        console.log("Changes found in the number of logged out students ");
                                        window.location.reload();
                                    } /*else {
                                        console.log("Parseresponse.loggedout " + parseresponse.loggedout);
                                        console.log("this.loggedout " + loggedout);
                                    }*/
                                }
                            }
                            ajaxReq.send(null);
                        } else {
                            document.getElementById(divID).innerHTML = "No AJAX request";
                        }
                    }, 10000);
                }

                let ajaxFunc = new AjaxFunction();
            </script>
    </head>
    <body onload="ajaxFunc.getData('monitorexam.php','logdetails')"> 
        <nav class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand">CBT</a>
                <button type="button" class="navbar-btn navbar-right btn btn-primary btn-sm"><i class="fa fa-user"></i> <?php print($_SESSION['username']); ?></button>
            </div>
        </nav>
        <div class="side-nav">
            <ul>
                <li class='active text-center'><a href="" style='font-size:17px;'><i class='fa fa-home'></i></a></li>
                <li><a href="exambound.php">School to take exams</a></li>
                <li><a href="" data-target="#selectSchExam" data-toggle="modal">Enter exam questions</a></li>
                <li><a href="viewresults.php">View student results</a></li>
                <li><a href="" data-target="#unblockstudent" data-toggle="modal">Unblock student</a></li>
                <li><a href="" data-target="#allowstudentlogin" data-toggle="modal">Allow student login</a></li>
                <li><a href="" data-target="#blockstudent" data-toggle="modal">Block student</a></li>
                <li><a href="blockauthorized.php">Block authorized departments</a></li>
                <li><a href="" data-target="#delquestions" data-toggle="modal">Delete existing questions</a></li>
                <li><a href="deleteanswers.php">Delete existing answers</a></li>
                
                <form method='GET' action=""><li><button style='width:100%' name='clearlog' type='submit' class='btn btn-warning'>Clear log</button></li>
                <li><button type="button" id="logoutBtn" type='submit' style='width:100%' name='logout' class="btn btn-danger"><i class="fa fa-sign-out"></i> End exam</button></li></form>

            </ul>
        </div>

        <div class='main-content'> <!-- START MAIN CONTENT -->
            <div class="container-fluid"> 
                <?php
                    require_once("clearlog.php");
                    class renderExamDetails extends adminConn {
                        //render template for active , blocked and students that have logged out
                        function __construct() {
                            parent::__construct();
                            $this->fetchStudentsWritingExams();
                        }
                        function fetchStudentsWritingExams() {
                            $sn = 1;
                            $lastrowId = 0; 
                            $inactiveuser = 0; //number of inactive users
                            $fetchDetails = $this->mysql->prepare("SELECT * FROM tbl_logforall");
                            $fetchDetails->execute();
                            if ($fetchDetails->rowCount() > 0) {
                                print("<table class='table table-hover table-condensed' style='width:100%;font-size:11px;'>
                                    <thead>
                                        <tr>
                                            <th>SN</th>
                                            <th>MATRIC NUMBER</th>
                                            <th>NAME</th>
                                            <th>FACULTY</th>
                                            <th>DEPARTMENT</th>
                                            <th>COURSE</th>
                                            <th>TIME LOGGED IN</th>
                                            <th>TIME LOGGED OUT</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>");
                                
                                while($getData = $fetchDetails->fetch(PDO::FETCH_ASSOC)) {
                                    $lastrowId = $getData['id'];
                                    $fetchBlocked = $this->mysql->prepare("SELECT * FROM tbl_blocked WHERE matricno = :matricnumber"); //check if the student has been blocked
                                    $fetchBlocked->bindParam(":matricnumber", $getData['matricno']);
                                    $fetchBlocked->execute();
                                    $timedifference = time() - (int)$getData['trackuseractivestate'];
                                    if ($fetchBlocked->rowCount() > 0) {
                                        $blockedStatus = "<button class='btn btn-danger btn-xs' id='blocked".$getData['matricno']."'>Blocked</button>";
                                    } else {
                                        $blockedStatus = "<button class='btn btn-primary btn-xs'>OK</button>";
                                    }
                                    //print("<h1>$timedifference</h1>");
                                    if ($timedifference > 15 && strlen($getData['timeloggedout']) == 0) {
                                        $inactiveuser = $inactiveuser + 1;
                                        $islogout = "<button class='btn btn-warning btn-xs'>Inactive</button>";
                                    } else if (strlen($getData['timeloggedout']) <= 0) {
                                        $islogout = "<button class='btn btn-success btn-xs'>Active</button>";
                                    } 
                                    if (strlen($getData['timeloggedout']) > 0) {
                                        $islogout = $getData['timeloggedout'];
                                    }
                                    print("<tr>
                                        <td>$sn</td>
                                        <td>".$getData['matricno']."</td>
                                        <td>".$getData['stuname']."</td>
                                        <td>".$getData['faculty']."</td>
                                        <td>".$getData['department']."</td>
                                        <td>".$getData['course']."</td>
                                        <td>".gmdate("H:i:s", (int)$getData['timeloggedin'])."</td>
                                        <td>".$islogout."</td>
                                        <td>".$blockedStatus."</td>
                                    </tr>");
                                    $sn++;
                                }
                                $fetchBlocked = null;
                                $getblocked = $this->mysql->prepare("SELECT * FROM tbl_blocked"); //check the number of blocked students
                                $getblocked->execute();
                                $number = $getblocked->rowCount();
                                $getblocked = null;

                                //getnumber of logged out students
                                $param = "";
                                $fetchloggedout = $this->mysql->prepare("SELECT * FROM tbl_logforall WHERE timeloggedout != :parameter"); //checks the number of logged out students
                                $fetchloggedout->bindParam(":parameter", $param);
                                $fetchloggedout->execute();
                                $numberofloggedout = $fetchloggedout->rowCount();
                                $fetchloggedout = null;

                                //update the javascript class member variables from this php code
                                print("<script>let lastrowid = ".json_encode($lastrowId).";
                                        ajaxFunc.lastrowfetchedid = parseInt(lastrowid);
                                        ajaxFunc.loggedout = ".json_encode($numberofloggedout).";
                                        ajaxFunc.blocked = ".json_encode($number).";
                                        ajaxFunc.online = ".json_encode($fetchDetails->rowCount()).";
                                        ajaxFunc.inactive = ".json_encode($inactiveuser)."
                                    </script>");
                                //end update
                                print("<div class='btn-group btn-group-sm pull-right'>
                                            <button class='btn btn-primary'>Total login : <span id='rownums'>" .$fetchDetails->rowCount(). "</span></button>
                                            <button class='btn btn-danger'>Blocked students : <span id='blockedstudents'>".$number."</span></button>
                                            <button class='btn btn-warning'>Inactive students : <span id='inactivestudents'>".$inactiveuser."</span></button>
                                            <button class='btn btn-success'>Logged Out students : <span id='loggedout'>".$numberofloggedout."</span></button>
                                        </div>"
                                    );
                                print("</tbody></table>");
                            } else {
                                print("<div class='alert alert-danger'>No student has logged in yet</div>");
                            }
                        }
                        function __destruct() {
                            $this->mysql = null;
                        }
                    }
                    $monExam = new renderExamDetails();
                ?>

                <div class='modal fade' id='unblockstudent'> <!-- Unblocks student from database -->
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button class="close" data-dismiss='modal'>&times;</button>
                                <h4>Unblock student</h4>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST">
                                    <div id="blockedstudentreport"></div>
                                    <div class="form-group">
                                        <label for="blockedstudent" class="control-label">Matric number</label>
                                        <input type="text" name="blockedstudent" id="blockedStudent" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" onclick="ajaxFunc.unblockstu(_$('blockedStudent').value)" class="btn btn-primary">Unblock</button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-danger" data-dismiss='modal'>Close window</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- End Modal -->

                <div class='modal fade' id='blockstudent'> <!-- blocks student from database -->
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button class="close" data-dismiss='modal'>&times;</button>
                                <h4>Block student</h4>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST">
                                    <div id="blockstureport"></div>
                                    <div class="form-group">
                                        <label for="blockedstudent" class="control-label">Matric number</label>
                                        <input type="text" name="blockstu" id="blockStu" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" onclick="ajaxFunc.blockstu(_$('blockStu').value)" class="btn btn-primary">Block</button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-danger" data-dismiss='modal'>Close window</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- End Modal -->

                <div class='modal fade' id='allowstudentlogin'> <!-- Unblocks student from database -->
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button class="close" data-dismiss='modal'>&times;</button>
                                <h4>Allow student log in</h4>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST">
                                    <div id="allowstubackin"></div>
                                    <div class="form-group">
                                        <label for="blockedstudent" class="control-label">Matric number</label>
                                        <input type="text" name="stumatno" id="stuMatNo" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" onclick="ajaxFunc.free(_$('stuMatNo').value)" class="btn btn-primary">Allow</button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-danger" data-dismiss='modal'>Close window</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- End Modal -->
                            
                <div class="modal fade" id="selectSchExam"> <!-- SELECT SCHOOL, LEVEL AND COURSE TO ENTER EXAM QUESTIONS -->
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <form method="POST" class="form" action="" id="selschform" name='quesform' onsubmit='return(val())'>
                                    <div class="form-group">
                                        <lebel class='control-label' for='school'>Enter course code</label>
                                        <input type='text' class='form-control' name='coursecode' id='courseCode'>
                                    </div>
                                    <div class="form-group">
                                        <lebel class='control-label' for='levels'>Level</label>
                                        <select class='form-control' name='levels'>
                                            <option>100</option>
                                            <option>200</option>
                                            <option>300</option>
                                            <option>400</option>
                                            <option>500</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-sm" name="saveQuesBtn">Next</button>
                                    </div>
                                    
                                </form>
                                <?php
                                    if (isset($_POST['saveQuesBtn'])) {
                                        $_SESSION['coursecode'] = strtoupper($_POST['coursecode']);
                                        $_SESSION['levels'] = $_POST['levels'];
                                        //print($_SESSION['schforexam']);
                                        print("<script>window.location.href = 'savequestions.php'</script>");
                                    }
                                ?>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-info" data-dismiss="modal">Close window</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- END MODAL -->

                <div class='modal fade' id='delquestions'> <!-- delete questions modal -->
                    <div class='modal-dialog'>
                        <div class='modal-content'>
                            <div class='modal-header'>
                                <button type='button' class='close' data-dismiss='modal'>&times;</button>
                                <h4>Delete questions</h4>
                            </div>
                            <div class='modal-body'>
                                <form class='form' action='deletequestions.php' method='POST'>
                                    <div class='row'>
                                        <select class="form-control" name="depts">
                                            <?php
                                                class fetchDepts extends adminConn {
                                                    function __construct() {
                                                        parent::__construct();

                                                        $this->getDepts();
                                                    }
                                                    function getDepts() {
                                                        $query = $this->mysql->prepare("SELECT * FROM tbl_departments");
                                                        $query->execute();
                                                        if ($query->rowCount() > 0) {
                                                            print("<option>All</option>");
                                                            while ($f = $query->fetch(PDO::FETCH_OBJ)) {
                                                                print("<option>".$f->departmentname."</option>");
                                                            }
                                                        }
                                                    }
                                                    function __destruct() {
                                                        $this->mysql = null;
                                                    }
                                                }
                                                $run = new fetchDepts();
                                            ?>
                                        </select>
                                    </div>
                                    <div class='form-group'>
                                        <button type='submit' class='btn btn-primary' name='deletedeptsbtn'>Delete</button>
                                    </div>
                                </form>
                            </div>
                            <div class='modal-footer'>
                                <button class='btn btn-danger' data-dismiss='modal' type='button'>Close window</div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end modal -->
                <div id='logdetails'></div>
            </div> <!-- END CONTAINER -->

        </div> <!-- END MAIN CONTENT -->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.1.js"></script>
        <!--  <script src="https://code.jquery.com/jquery.js"></script> -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/JavaScript" src="js/bootstrap.min.js"></script>

    
     </body>
</html>