function validate() {
    var schoolOption = document.getElementsByName("school");
    var opt;
    for (var i = 0; i < schoolOption.length; i++) {
        if (schoolOption[i].checked) {
            opt = schoolOption[i];
        }
    }
    if (opt == null) {
        document.getElementById("report1").innerHTML = "<div class='alert alert-danger'>You did not select any option</div>";
    }
    
}